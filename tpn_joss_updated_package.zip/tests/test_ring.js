// ring tests
