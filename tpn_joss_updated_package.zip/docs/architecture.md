Architecture description.
