Full JOSS paper placeholder.
