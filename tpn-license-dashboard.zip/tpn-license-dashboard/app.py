"""
app.py
──────
TPN License Intelligence Dashboard — Flask application server
Version: 8.0.0

Run:   python app.py
Open:  http://localhost:5000

Routes
──────
GET  /                  Serves the dashboard UI
POST /api/parse-pdf     Accepts PDF upload → returns JSON rows + stats
POST /api/export-xlsx   Accepts JSON rows → returns formatted .xlsx download
GET  /api/health        Health check → returns version info

File structure
──────────────
app.py                  ← this file (Flask server)
core/
  pdf_parser.py         ← v8.0.0 hierarchical TPN parser
  excel_export.py       ← v2.0.0 XLSX export (12-sheet workbook)
static/
  dashboard.css         ← styles
  dashboard.js          ← client-side logic
  demo.config.js        ← demo data config
  favicon.svg           ← browser tab icon
templates/
  dashboard.html        ← main UI template
uploads/                ← temp upload directory (auto-created)
requirements.txt        ← pip dependencies
"""

import io
import os
from flask import Flask, render_template, request, jsonify, send_file
from core.pdf_parser   import parse_pdf, compute_stats, PARSER_VERSION
from core.excel_export import build_xlsx
from core.ai_enricher  import enrich_unknown_rows

# ─────────────────────────────────────────────────────────────────────────────
# App setup
# ─────────────────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024   # 100 MB upload limit

# Ensure uploads directory exists
os.makedirs('uploads', exist_ok=True)


@app.after_request
def no_cache(response):
    """Disable browser caching for static files so updates apply immediately."""
    if request.path.startswith('/static/'):
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma']        = 'no-cache'
        response.headers['Expires']       = '0'
    return response


# ─────────────────────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/favicon.ico')
def favicon():
    return send_file('static/favicon.svg', mimetype='image/svg+xml')


@app.route('/')
def index():
    """Serve the main dashboard page."""
    return render_template('dashboard.html')


@app.route('/api/health')
def health():
    """Health check — returns version info."""
    return jsonify({
        'status':         'ok',
        'parser_version': PARSER_VERSION,
        'app_version':    '9.0.0',
    })


@app.route('/api/parse-pdf', methods=['POST'])
def api_parse_pdf():
    """
    Parse an uploaded Third-Party Notices PDF.

    Request
    -------
    multipart/form-data
      file: <PDF file>

    Response 200
    ------------
    {
      "rows":  [ { page, l1, l2, l3, flag, risk, risk_level, label,
                   reason, is_heading_page, is_noise, page_mode }, ... ],
      "stats": { total, total_pages, flagged, by_mode,
                 gpl, weak_copyleft, apache, permissive,
                 public, content, prop, non_oss, unknown }
    }

    Response 400 / 500
    ------------------
    { "error": "<message>" }
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file field in request'}), 400

    f = request.files['file']

    if not f.filename:
        return jsonify({'error': 'No file selected'}), 400

    if not f.filename.lower().endswith('.pdf'):
        return jsonify({'error': 'Only PDF files are accepted (.pdf extension required)'}), 400

    try:
        pdf_bytes = f.read()
        if len(pdf_bytes) == 0:
            return jsonify({'error': 'Uploaded file is empty'}), 400

        rows  = parse_pdf(pdf_bytes)
        stats = compute_stats(rows)

        return jsonify({
            'rows':     rows,
            'stats':    stats,
            'filename': f.filename,
        })

    except Exception as e:
        return jsonify({'error': f'Parse error: {e}'}), 500


@app.route('/api/enrich-unknown', methods=['POST'])
def api_enrich_unknown():
    """
    AI-powered enrichment for rows the keyword parser could not classify.

    Request
    -------
    Content-Type: application/json
    { "rows": [ ...parsed rows... ] }

    Response 200
    ------------
    {
      "rows":  [ ...updated rows with AI flags... ],
      "stats": { total, total_pages, flagged, ... },
      "enrichment": {
        "total_unknown": int,
        "enriched":      int,
        "still_unknown": int,
        "api_calls":     int,
        "errors":        []
      }
    }
    """
    data = request.get_json(force=True, silent=True)
    if not data or 'rows' not in data:
        return jsonify({'error': 'JSON must contain a "rows" array'}), 400

    rows = data['rows']
    if not isinstance(rows, list):
        return jsonify({'error': '"rows" must be an array'}), 400

    try:
        enrichment_stats = enrich_unknown_rows(rows)
        updated_stats    = compute_stats(rows)
        return jsonify({
            'rows':       rows,
            'stats':      updated_stats,
            'enrichment': enrichment_stats,
        })
    except Exception as e:
        return jsonify({'error': f'Enrichment error: {e}'}), 500


@app.route('/api/export-xlsx', methods=['POST'])
def api_export_xlsx():
    """
    Export parsed TPN data to a formatted XLSX workbook.

    Request
    -------
    Content-Type: application/json
    { "rows": [ ... ] }

    Response 200
    ------------
    application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
    Filename: third-party-notices.xlsx

    Response 400 / 500
    ------------------
    { "error": "<message>" }
    """
    data = request.get_json(force=True, silent=True)
    if not data:
        return jsonify({'error': 'Request body must be JSON'}), 400
    if 'rows' not in data or not isinstance(data['rows'], list):
        return jsonify({'error': 'JSON must contain a "rows" array'}), 400

    try:
        xlsx_bytes = build_xlsx(data['rows'])
        return send_file(
            io.BytesIO(xlsx_bytes),
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='third-party-notices.xlsx',
        )
    except Exception as e:
        return jsonify({'error': f'Export error: {e}'}), 500


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print()
    print('  ┌──────────────────────────────────────────────────────┐')
    print('  │  TPN License Intelligence Dashboard  v9.0.0          │')
    print('  │                                                      │')
    print(f'  │  Parser:  v{PARSER_VERSION} (3-mode state machine)       │')
    print('  │  Open:    http://localhost:5000                      │')
    print('  │  Health:  http://localhost:5000/api/health           │')
    print('  └──────────────────────────────────────────────────────┘')
    print()
    app.run(debug=True, port=5000, host='0.0.0.0')
