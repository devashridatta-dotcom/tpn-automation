r"""
core/pdf_parser.py  v10.2.0
───────────────────────────
Vendor-agnostic, multi-stage TPN parser.

ARCHITECTURE
============
Each component block is classified through a four-stage pipeline:

  Stage 1 — Heading name classification
    Classify the license name string extracted from the "Audit - Owner - License"
    heading line.  Uses SPDX ID lookup, copyleft family keywords, dual/OR
    resolver, content/font, proprietary, permissive, and public-domain layers.

  Stage 2 — Body phrase signature scan
    When Stage 1 returns 'unknown', scan accumulated body-page text for license
    signature phrases (MIT grant, BSD redistribution, GPL, Apache, zlib, public
    domain, proprietary "all rights reserved", etc.).

  Stage 3 — Custom-license fallback
    If Stage 2 finds body text but no pattern, label as
    'unknown — Custom license, N words, manual review required'.

  Stage 4 — Inherited context
    Body pages inherit the classification from their heading block.
    Inheritance resets on every new heading.

CLASSIFICATION LAYERS (Stage 1)
================================
 L1  Dual/OR resolver   — OR=least-restrictive, AND/|/space+/,/&=most-restrictive
 L2  SPDX identifiers   — exact SPDX IDs (120+ entries)
 L3  Copyleft families  — GPL/LGPL/MPL/EPL/CDDL/Artistic/AFL/EUPL
 L4  Content/Font       — OFL, CC-BY, Creative Commons, GFDL
 L5  Non-OSS            — field-of-use restriction phrases
 L6  Proprietary strong — EULA, confidential, all-rights-reserved, no-redistrib
 L7  Government         — FAR/DFAR, NASA, DoD
 L8  Apache             — Apache keyword
 L9  Permissive OSS     — MIT/BSD/ISC/Zlib/X11/Boost/PSF/HPND + compressed forms
 L10 Public domain      — CC0/CCO/Unlicense/Public Domain
 L11 Proprietary weak   — "proprietary", "restricted use", commercial software
 L12 Filename guard     — file extensions (.h/.c/.doc/.txt) → unknown
 L13 Unknown fallback   — manual review required

CC RISK DIFFERENTIATION
========================
CC0          → public   (MINIMAL — no obligations)
CC-BY        → content  (LOW — attribution only)
CC-BY-SA     → content  (LOW-MEDIUM — share-alike)
CC-BY-NC/ND  → non_oss  (HIGH — field-of-use restriction)

DUAL-LICENSE POLICY
===================
OR  → least restrictive  ("MIT or GPL" → permissive)
AND / space-flanked | / / / , / &  → most restrictive  ("MIT and GPL" → gpl)

FORMAT SUPPORT
==============
Format 1 — "Audit - Copyright Owner - License Name"  (Blackduck/Scancode)
Format 2 — "pkgname [version] (SPDX-ID)" + "(None)" in l2  (Yocto/BitBake)
Format 3 — Summary aggregate: "CategoryName: N components (Risk)"

VERSION HISTORY
===============
v10.2.0  BSD2/GPL2 compressed forms; zlib no-quotes body sig; permission grant
         body sig broadened; public-domain "released into" body sig; filename
         guard (L12) prevents .h/.c/.doc filenames from matching GPL/MIT keywords.
v10.1.0  BSD N-clause fix, SDK/WDK prop, notshipping, Spencer regex, SGI FreeB/GLX,
         CCO typo normalisation, component-prefix stripper safety guard.
v10.0.0  Multi-stage pipeline: heading + body-phrase scan + custom fallback.
         CC flavor differentiation.  Improved heading extraction.
v9.2.0   AND-connector fix (,/&/space-/), degenerate-heading stickiness fix.
v9.1.0   Full vendor-agnostic rewrite.
v9.0.0   Dual-format heading detection (Audit + pkg-SPDX).
"""

PARSER_VERSION = "10.3.0"

import re
import io
import unicodedata
from enum import Enum, auto

import pypdf


# ─────────────────────────────────────────────────────────────────────────────
# Summary-format PDF
# ─────────────────────────────────────────────────────────────────────────────
_SUMMARY_LINE_RE = re.compile(
    r'^(.+?):\s+(\d+)\s+components?\s*\(([^)]+)\)',
    re.IGNORECASE | re.MULTILINE,
)

_SUMMARY_CAT_TO_FLAG: dict[str, str] = {
    'permissive': 'permissive', 'apache': 'apache', 'apache-2.0': 'apache',
    'apache 2.0': 'apache', 'weak copyleft': 'weak_copyleft',
    'weak_copyleft': 'weak_copyleft', 'strong copyleft': 'gpl', 'gpl': 'gpl',
    'non-oss': 'non_oss', 'non_oss': 'non_oss', 'non oss': 'non_oss',
    'proprietary': 'prop', 'public domain': 'public',
    'public domain/cc0': 'public', 'public domain / cc0': 'public',
    'cc0': 'public', 'unlicense': 'public', 'content': 'content',
    'content/font': 'content', 'content / font': 'content', 'font': 'content',
    'unknown': 'unknown', 'unclassified': 'unknown',
    'unknown / unclassified': 'unknown',
}


# ─────────────────────────────────────────────────────────────────────────────
# Page mode
# ─────────────────────────────────────────────────────────────────────────────
class PageMode(Enum):
    PRE_HEADING = auto()
    HEADING     = auto()
    BODY        = auto()


# ─────────────────────────────────────────────────────────────────────────────
# Heading detectors
# ─────────────────────────────────────────────────────────────────────────────
AUDIT_RE = re.compile(
    r'^Audit\s*[-\u2013\u2014]\s*(?:Copy(?:right|rigth|write|wrigt)\s+)?'
    r'(.+?)\s*[-\u2013\u2014]\s*(.+)$',
    re.IGNORECASE,
)

_PKG_SPDX_RE = re.compile(
    r'^([\w][\w\-\.\+\s]{0,80}?)\s*\(([^)]{2,120})\)\s*$',
    re.IGNORECASE,
)

_BODY_TEXT_RE = re.compile(
    r'^(?:You |We |This |The |IN NO EVENT|BECAUSE|IF |HOWEVER|A\s+'
    r'|Subject to|Permission is|Redistribution|Copyright \(c\)'
    r'|Copyright \u00a9|(?:THE|THIS|ALL) (?:SOFTWARE|PROGRAM|LIBRARY|WORK))',
    re.IGNORECASE,
)

_META_LINE_RE = re.compile(
    r'^\s*(-{4,}|={4,}|Attribution Statements|License Text|Copyright Statements'
    r'|Source Distribution URL|\(None\)|Page \d+|General)\s*$',
    re.IGNORECASE,
)


def _is_audit_heading(l1: str) -> bool:
    return bool(AUDIT_RE.match(l1.strip()))


def _is_pkg_spdx_heading(lines: list[str]) -> bool:
    l1 = lines[0].strip() if lines else ''
    l2 = lines[1].strip() if len(lines) > 1 else ''
    if _is_audit_heading(l1) or _BODY_TEXT_RE.match(l1) or _META_LINE_RE.match(l1):
        return False
    if not re.match(
        r'^\(None\)$|^Attribution Statements$|^License Text$|^Copyright Statements$',
        l2, re.IGNORECASE
    ):
        return False
    return bool(_PKG_SPDX_RE.match(l1))


def _is_heading_page(lines: list[str]) -> bool:
    l1 = next((l for l in lines if l.strip()), '')
    return _is_audit_heading(l1) or _is_pkg_spdx_heading(lines)


def _extract_heading_license(lines: list[str]) -> str | None:
    """
    Extract the license name from a heading page.
    For Audit format: strips the component-name prefix so we get just the license.
    E.g. "libcurl - Curl License" → "Curl License"
         "certificates - GNU GPL" → "GNU GPL"
         "BSD 3-clause License"   → "BSD 3-clause License"  (already clean)
    """
    l1 = lines[0].strip() if lines else ''
    l2 = lines[1].strip() if len(lines) > 1 else ''

    if _is_pkg_spdx_heading(lines):
        m = _PKG_SPDX_RE.match(l1)
        return m.group(2).strip() if m else None

    # Audit format — join continuation lines
    joined = l1
    if l2 and not l2.startswith('(') and not re.match(r'^https?://', l2):
        if l1.rstrip()[-1:] in '-\u2013\u2014':
            joined = l1.rstrip(' -\u2013\u2014') + ' ' + l2
        elif not re.search(
            r'(licen|licence|GPL|LGPL|MPL|EPL|CDDL|MIT|BSD|Apache|Public.Domain|'
            r'Proprietary|zlib|ISC|Boost|OpenSSL|libpng|CC0|Unlicense|EULA|FTL|'
            r'Copyleft|Confidential|Unknown|Custom|Artistic|Perl|OFL|Font|CC-BY|'
            r'Curl|JsonCpp|Spencer|XFree|LPPL|SIL|Twemoji|Creative.Commons|'
            r'Beerware|Bison|GCC|Autoconf|Libtool|Classpath|Library|Lesser|'
            r'WTFPL|AFL|AGPL|Affero|WordNet)',
            l1, re.IGNORECASE,
        ):
            joined = l1 + ' ' + l2
        elif re.search(
            r'\b(Public|General|Lesser|Library|Attribution|ShareAlike|International|'
            r'Common|Development|Distribution|Open|Creative|Version)\s*$',
            l1, re.IGNORECASE,
        ):
            joined = l1 + ' ' + l2

    m = AUDIT_RE.match(joined)
    if not m:
        return None

    lic = m.group(2).strip()

    # Strip leading component-name prefix from the license token ONLY when
    # the prefix is NOT itself a license keyword.
    # ✓ "libcurl - Curl License"       → "Curl License"
    # ✓ "certificates - GNU GPL"       → "GNU GPL"
    # ✗ "BSD 3-clause License"         → keep as-is  (BSD is a license keyword)
    # ✗ "GNU General Public License"   → keep as-is  (GPL keyword)
    _LIC_KEYWORD_START = re.compile(
        r'^(?:GPL|LGPL|MIT|BSD|Apache|GNU|Mozilla|Eclipse|CDDL|'
        r'Artistic|AFL|EUPL|OSL|CC0|CC-BY|OFL|SIL|Zlib|ISC|Boost|'
        r'OpenSSL|X11|NCSA|FTL|PSF|HPND|Public|Proprietary|'
        r'Confidential|EULA|Not.?[Ss]hip)',
        re.IGNORECASE,
    )
    if not _LIC_KEYWORD_START.match(lic):
        lic_stripped = re.sub(
            r'^[\w][\w\-\.]{0,40}\s+[-\u2013\u2014]\s*',
            '',
            lic,
        )
        # Accept stripped version only if it still has a license keyword
        if lic_stripped and re.search(
            r'(licen|licence|GPL|LGPL|MPL|MIT|BSD|Apache|Public.Domain|Proprietary|'
            r'zlib|ISC|Boost|OpenSSL|CC|OFL|Font|Curl|Bison|GCC|Affero|AGPL|'
            r'Artistic|Perl|WTFPL|AFL|EUPL|OSL|CDDL|EPL|Unlicense|HPND|PSF|FTL|'
            r'X11|NCSA|Copyleft|EULA|Confidential|Commercial|clause)',
            lic_stripped, re.IGNORECASE,
        ):
            lic = lic_stripped

    if len(lic) <= 4 and l2 and not l2.startswith('('):
        lic = lic + ' ' + l2
    return lic.strip()


# ─────────────────────────────────────────────────────────────────────────────
# Noise / degenerate-heading detectors
# ─────────────────────────────────────────────────────────────────────────────
_NOISE_PKG_RE = re.compile(r'^[\w][\w\-\.\s]{0,60}\s+\([\w\.\-]+\)\s*$', re.I)
_NOISE_META_RE = re.compile(
    r'^-{4,}$|^={4,}$|^Attribution Statements$|^License Text$'
    r'|^\(None\)$|^General$|^Source Distribution URL$',
    re.IGNORECASE,
)


def _is_noise_page(lines: list[str]) -> bool:
    l1 = lines[0].strip() if lines else ''
    return bool(_NOISE_META_RE.match(l1) or _NOISE_PKG_RE.match(l1))


_DEGENERATE_LICENSE_RE = re.compile(
    r'^(?:License\s+Text|Attribution\s+Statements?|License\s*$'
    r'|Copyright\s+Statements?|Source\s+Distribution\s*(?:URL)?'
    r'|See\s+(?:License|Above)|Refer\s+to\s+License'
    r'|N/?A|None|Unknown\s*License?\s*$'
    r'|License\s+Agreement\s*$)\s*$',
    re.IGNORECASE,
)


def _is_degenerate_heading(lic_str: str | None) -> bool:
    if not lic_str:
        return True
    return bool(_DEGENERATE_LICENSE_RE.match(lic_str.strip()))


# ─────────────────────────────────────────────────────────────────────────────
# Category metadata
# ─────────────────────────────────────────────────────────────────────────────
CATEGORY_META = {
    'gpl':           {'label': 'GPL / Strong Copyleft',  'risk': 'HIGH — source disclosure required',      'risk_level': 'high'},
    'weak_copyleft': {'label': 'Weak Copyleft',          'risk': 'MED-HIGH — file/module-level copyleft',  'risk_level': 'med-high'},
    'apache':        {'label': 'Apache',                 'risk': 'MEDIUM — notice + NOTICE file required', 'risk_level': 'medium'},
    'permissive':    {'label': 'Permissive',             'risk': 'LOW — attribution notice only',          'risk_level': 'low'},
    'public':        {'label': 'Public Domain / CC0',    'risk': 'MINIMAL — no obligations',               'risk_level': 'minimal'},
    'content':       {'label': 'Content / Font License', 'risk': 'LOW — attribution / embedding rules',    'risk_level': 'low'},
    'prop':          {'label': 'Proprietary',            'risk': 'HIGH — redistribution restricted',       'risk_level': 'high'},
    'prop_sdk':      {'label': 'Proprietary (SDK/EULA)', 'risk': 'HIGH — SDK redistribution terms apply',  'risk_level': 'high'},
    'non_oss':       {'label': 'Non-OSS / Restrictive',  'risk': 'HIGH — field-of-use restrictions',       'risk_level': 'high'},
    # ── Stage 5: structured unknown subtypes ─────────────────────────────────
    # These replace the generic "Unknown / Unclassified CRITICAL" with
    # actionable, specific categories so reviewers know exactly what they face.
    'unknown':       {'label': 'Unknown / Unclassified', 'risk': 'CRITICAL — manual review required',      'risk_level': 'critical'},
    'unknown_custom':{'label': 'Custom License',         'risk': 'CRITICAL — non-standard license text, manual review', 'risk_level': 'critical'},
    'unknown_cr_only': {'label': 'Copyright Notice Only','risk': 'HIGH — no license grant found, treat as proprietary', 'risk_level': 'high'},
    'unknown_non_sw':{'label': 'Non-Software Material',  'risk': 'LOW — document/spec, not a software license', 'risk_level': 'low'},
    'unknown_oss_review': {'label': 'OSS-Adjacent (Review)', 'risk': 'MEDIUM — partial OSS text, manual review required', 'risk_level': 'medium'},
}
_FLAG_NORMALISE = {
    'prop_sdk':           'prop',
    # Stage 5 subtypes normalise to 'unknown' for stat counting purposes,
    # but keep their own label/risk in CATEGORY_META for the dashboard display.
    # (They are NOT normalised here so the dashboard can show differentiated labels.)
}

PARSER_VERSION = "10.3.0"


# ─────────────────────────────────────────────────────────────────────────────
# Summary-format support
# ─────────────────────────────────────────────────────────────────────────────
def _is_summary_format(full_text: str) -> bool:
    has_summary_header = bool(re.search(
        r'Summary\s+by\s+License\s+Categor|License\s+Category\s+Summary',
        full_text, re.IGNORECASE,
    ))
    matches = _SUMMARY_LINE_RE.findall(full_text)
    has_audit_lines = bool(re.search(r'^Audit\s*[-\u2013\u2014]', full_text,
                                     re.MULTILINE | re.IGNORECASE))
    return (has_summary_header or len(matches) >= 3) and not has_audit_lines


def _parse_summary_pdf(full_text: str, pdf_bytes: bytes) -> list[dict]:
    proj_m = re.search(r'Project:\s*(.+)', full_text)
    project = proj_m.group(1).strip() if proj_m else 'Unknown Project'
    gen_m = re.search(r'Generated On:\s*(.+)', full_text)
    generated = gen_m.group(1).strip() if gen_m else ''
    rows: list[dict] = []
    page = 1
    for cat_raw, count_str, _ in _SUMMARY_LINE_RE.findall(full_text):
        cat_key = cat_raw.strip().lower()
        flag = _SUMMARY_CAT_TO_FLAG.get(cat_key, 'unknown')
        count = int(count_str)
        meta = CATEGORY_META.get(flag, CATEGORY_META['unknown'])
        for i in range(count):
            rows.append({
                'page': page,
                'l1': f'[Summary] {meta["label"]} — component {i+1} of {count}',
                'l2': project, 'l3': generated, 'flag': flag,
                'risk': meta['risk'], 'risk_level': meta['risk_level'],
                'label': meta['label'],
                'reason': (f'Summary format: {cat_raw.strip()} → {meta["label"]} '
                           f'({count} total in {project})'),
                'is_heading_page': True, 'is_noise': False, 'page_mode': 'HEADING',
            })
            page += 1
    return rows


# ─────────────────────────────────────────────────────────────────────────────
# SPDX identifier table  (120+ entries, vendor-agnostic)
# ─────────────────────────────────────────────────────────────────────────────
_SPDX_TO_FLAG: dict[str, str] = {
    'AGPL-1.0': 'gpl', 'AGPL-3.0': 'gpl',
    'GPL-1.0': 'gpl', 'GPL-2.0': 'gpl', 'GPL-3.0': 'gpl',
    'GPL-2.0-only': 'gpl', 'GPL-3.0-only': 'gpl',
    'GPL-2.0-or-later': 'gpl', 'GPL-3.0-or-later': 'gpl',
    'GPL-1.0-or-later': 'gpl', 'GPL-1.0-only': 'gpl',
    'GPL-2.0-with-autoconf-exception': 'gpl',
    'GPL-2.0-with-bison-exception': 'gpl',
    'GPL-3.0-with-autoconf-exception': 'gpl',
    'GPL-3.0-with-GCC-exception': 'gpl',
    'LGPL-2.0': 'weak_copyleft', 'LGPL-2.1': 'weak_copyleft', 'LGPL-3.0': 'weak_copyleft',
    'LGPL-2.0-only': 'weak_copyleft', 'LGPL-2.1-only': 'weak_copyleft', 'LGPL-3.0-only': 'weak_copyleft',
    'LGPL-2.0-or-later': 'weak_copyleft', 'LGPL-2.1-or-later': 'weak_copyleft', 'LGPL-3.0-or-later': 'weak_copyleft',
    'MPL-1.0': 'weak_copyleft', 'MPL-1.1': 'weak_copyleft', 'MPL-2.0': 'weak_copyleft',
    'MPL-2.0-no-copyleft-exception': 'weak_copyleft',
    'EPL-1.0': 'weak_copyleft', 'EPL-2.0': 'weak_copyleft',
    'CDDL-1.0': 'weak_copyleft', 'CDDL-1.1': 'weak_copyleft',
    'EUPL-1.0': 'weak_copyleft', 'EUPL-1.1': 'weak_copyleft', 'EUPL-1.2': 'weak_copyleft',
    'OSL-1.0': 'weak_copyleft', 'OSL-2.0': 'weak_copyleft', 'OSL-3.0': 'weak_copyleft',
    'Artistic-1.0': 'weak_copyleft', 'Artistic-2.0': 'weak_copyleft',
    'AFL-1.1': 'weak_copyleft', 'AFL-1.2': 'weak_copyleft',
    'AFL-2.0': 'weak_copyleft', 'AFL-2.1': 'weak_copyleft', 'AFL-3.0': 'weak_copyleft',
    'CPOL-1.02': 'weak_copyleft',
    'CECILL-2.0': 'weak_copyleft', 'CECILL-2.1': 'weak_copyleft',
    'Apache-1.0': 'apache', 'Apache-1.1': 'apache', 'Apache-2.0': 'apache',
    'MIT': 'permissive', 'MIT-0': 'permissive',
    'BSD-1-Clause': 'permissive', 'BSD-2-Clause': 'permissive',
    'BSD-3-Clause': 'permissive', 'BSD-4-Clause': 'permissive',
    'BSD-2-Clause-Patent': 'permissive', 'BSD-2-Clause-Views': 'permissive',
    'BSD-3-Clause-Clear': 'permissive', 'BSD-4-Clause-UC': 'permissive',
    'ISC': 'permissive',
    'Zlib': 'permissive', 'zlib-acknowledgement': 'permissive',
    'Libpng': 'permissive', 'libpng-2.0': 'permissive',
    'OpenSSL': 'permissive', 'SSLeay': 'permissive',
    'BSL-1.0': 'permissive',
    'X11': 'permissive', 'X11-distribute-modifications-variant': 'permissive',
    'XFree86-1.1': 'permissive',
    'NCSA': 'permissive',
    'FTL': 'permissive',
    'IJG': 'permissive', 'IJG-short': 'permissive',
    'PSF-2.0': 'permissive', 'Python-2.0': 'permissive',
    'Lua': 'permissive',
    'curl': 'permissive',
    'WTFPL': 'permissive',
    'Info-ZIP': 'permissive',
    'Artistic-1.0-Perl': 'permissive',
    'NTP': 'permissive', 'NTP-0': 'permissive',
    'W3C': 'permissive', 'W3C-19980720': 'permissive', 'W3C-20150513': 'permissive',
    'PostgreSQL': 'permissive',
    'Beerware': 'permissive',
    'Vim': 'permissive',
    'HPND': 'permissive',
    'MIT-Modern-Variant': 'permissive',
    'Unicode-DFS-2015': 'permissive', 'Unicode-DFS-2016': 'permissive',
    'Unicode-TOU': 'permissive',
    'Intel': 'permissive',
    'blessing': 'permissive',
    'SQLite': 'permissive',
    'libtiff': 'permissive',
    'Spencer-86': 'permissive', 'Spencer-94': 'permissive', 'Spencer-99': 'permissive',
    'MIT-CMU': 'permissive', 'MIT-advertising': 'permissive',
    'Naumen': 'permissive',
    'NBPL-1.0': 'permissive',
    'SMLNJ': 'permissive', 'StandardML-NJ': 'permissive',
    'FSFAP': 'permissive',
    'TCP-wrappers': 'permissive',
    'TMATE': 'permissive',
    'ZPL-1.1': 'permissive', 'ZPL-2.0': 'permissive', 'ZPL-2.1': 'permissive',
    # CC variants — differentiated
    'CC0-1.0': 'public',                                            # public domain
    'CC-BY-1.0': 'content', 'CC-BY-2.0': 'content',               # attribution only
    'CC-BY-2.5': 'content', 'CC-BY-3.0': 'content',
    'CC-BY-4.0': 'content',
    'CC-BY-SA-1.0': 'content', 'CC-BY-SA-2.0': 'content',         # share-alike
    'CC-BY-SA-2.5': 'content', 'CC-BY-SA-3.0': 'content',
    'CC-BY-SA-4.0': 'content',
    'CC-BY-NC-1.0': 'non_oss', 'CC-BY-NC-2.0': 'non_oss',        # non-commercial = field-of-use
    'CC-BY-NC-2.5': 'non_oss', 'CC-BY-NC-3.0': 'non_oss',
    'CC-BY-NC-4.0': 'non_oss',
    'CC-BY-ND-1.0': 'non_oss', 'CC-BY-ND-2.0': 'non_oss',        # no derivatives = restrictive
    'CC-BY-ND-3.0': 'non_oss', 'CC-BY-ND-4.0': 'non_oss',
    'CC-BY-NC-SA-1.0': 'non_oss', 'CC-BY-NC-SA-2.0': 'non_oss',
    'CC-BY-NC-SA-3.0': 'non_oss', 'CC-BY-NC-SA-4.0': 'non_oss',
    'CC-BY-NC-ND-1.0': 'non_oss', 'CC-BY-NC-ND-2.0': 'non_oss',
    'CC-BY-NC-ND-3.0': 'non_oss', 'CC-BY-NC-ND-4.0': 'non_oss',
    # Font
    'OFL-1.0': 'content', 'OFL-1.1': 'content',
    'LPPL-1.0': 'content', 'LPPL-1.1': 'content',
    'LPPL-1.2': 'content', 'LPPL-1.3a': 'content', 'LPPL-1.3c': 'content',
    'Bitstream-Vera': 'content', 'Bitstream-Charter': 'content',
    # Non-OSS
    'JSON': 'non_oss',
    # Unlicense / public domain
    'Unlicense': 'public', 'PDDL-1.0': 'public', 'SAX-PD': 'public',
}

_SPDX_ID_RE = re.compile(
    r'(?<![A-Za-z0-9\-])('
    + '|'.join(re.escape(k) for k in sorted(_SPDX_TO_FLAG, key=len, reverse=True))
    + r')(?![A-Za-z0-9\-])',
    re.IGNORECASE,
)


def _match_spdx(s: str) -> tuple[str, str] | None:
    m = _SPDX_ID_RE.search(s)
    if not m:
        return None
    matched = m.group(1)
    for key, flag in _SPDX_TO_FLAG.items():
        if key.lower() == matched.lower():
            return flag, key
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Copyleft family detectors
# ─────────────────────────────────────────────────────────────────────────────
_LGPL_RE = re.compile(
    r'\bLGPL\b|\bLGPLv?[0-9]|LGPL-[0-9]'
    r'|GNU\s+LESSER\s+GENERAL\s+PUBLIC'
    r'|LESSER\s+GENERAL\s+PUBLIC'
    r'|LIBRARY\s+GENERAL\s+PUBLIC'
    r'|GNU\s+LIBRARY\s+GPL',
    re.IGNORECASE,
)
_GPL_RE = re.compile(
    r'(?<![A-Za-z])GPL(?![A-Za-z])'
    r'|(?<![A-Za-z])GPL[-v/]?[0-9]'
    r'|GNU\s+GENERAL\s+PUBLIC'
    r'|AFFERO|\bAGPL\b'
    r'|BISON[\s.]EXCEPTION|GCC[\s.]RUNTIME'
    r'|AUTOCONF.*EXCEPTION|LIBTOOL.*EXCEPTION'
    r'|CLASSPATH[\s.]EXCEPTION',
    re.IGNORECASE,
)
_MPL_RE  = re.compile(r'\bMPL\b|\bMPLv?[0-9]|MOZILLA\s+PUBLIC', re.IGNORECASE)
_EPL_RE  = re.compile(r'\bEPL\b|\bEPLv?[0-9]|ECLIPSE\s+PUBLIC', re.IGNORECASE)
_CDDL_RE = re.compile(r'\bCDDL\b|COMMON\s+DEVELOPMENT\s+AND\s+DISTRIBUTION', re.IGNORECASE)
_ART_RE  = re.compile(r'ARTISTIC[\s.\-]LICEN|ARTISTIC-[0-9]|\bARTISTIC\b|PERL\s+LICEN|\bPERL\b', re.IGNORECASE)
_AFL_RE  = re.compile(r'\bAFL[-\s]?[0-9]|\bAFL\b|ACADEMIC\s+FREE\s+LICEN', re.IGNORECASE)
_EUPL_RE = re.compile(r'\bEUPL\b|EUROPEAN\s+UNION\s+PUBLIC', re.IGNORECASE)
_OSL_RE  = re.compile(r'\bOSL[-\s]?[0-9]|OPEN\s+SOFTWARE\s+LICEN', re.IGNORECASE)


def _has_lgpl(s: str) -> bool: return bool(_LGPL_RE.search(s))
def _has_gpl(s: str) -> bool:  return bool(_GPL_RE.search(_LGPL_RE.sub('', s)))
def _has_mpl(s: str) -> bool:  return bool(_MPL_RE.search(s))
def _has_epl(s: str) -> bool:  return bool(_EPL_RE.search(s))
def _has_cddl(s: str) -> bool: return bool(_CDDL_RE.search(s))
def _has_art(s: str) -> bool:  return bool(_ART_RE.search(s))
def _has_afl(s: str) -> bool:  return bool(_AFL_RE.search(s))
def _has_eupl(s: str) -> bool: return bool(_EUPL_RE.search(s))
def _has_osl(s: str) -> bool:  return bool(_OSL_RE.search(s))


# ─────────────────────────────────────────────────────────────────────────────
# Dual / OR resolver
# ─────────────────────────────────────────────────────────────────────────────
def _dual_license_resolve(s: str) -> tuple[str, str] | None:
    has_or  = bool(re.search(r'\bor\b', s, re.IGNORECASE))
    # AND connectors: "and" keyword, or space-flanked | / , &
    has_and = (bool(re.search(r'\band\b', s, re.IGNORECASE)) or
               bool(re.search(r'\s[|/,&]\s', s)))
    if not has_or and not has_and:
        return None

    has_gpl    = _has_gpl(s)
    has_lgpl   = _has_lgpl(s)
    has_weak   = (has_lgpl or _has_mpl(s) or _has_epl(s) or _has_cddl(s)
                  or _has_art(s) or _has_afl(s) or _has_eupl(s) or _has_osl(s))
    has_apache = bool(re.search(r'\bAPACHE\b', s, re.I))
    has_perm   = bool(re.search(
        r'\bMIT\b|\bBSD\b|\bISC\b|\bZLIB\b|\bBoost\b|BSL-1\.0'
        r'|\bCurl\b|XFree86|\bPSF\b|\bLua\b'
        r'|\bWTFPL\b|\bUnlicense\b|\bCC0\b|\bHPND\b|\bNTP\b|\bW3C\b'
        r'|\bBeerware\b|\bVim\b|\bSQLite\b|\bZlib\b', s, re.I))

    if sum(bool(x) for x in [has_gpl, has_weak, has_apache, has_perm]) < 2:
        return None

    if has_and:
        if has_gpl:    return 'gpl',           'AND-license: GPL most restrictive'
        if has_lgpl:   return 'weak_copyleft', 'AND-license: LGPL most restrictive'
        if has_weak:   return 'weak_copyleft', 'AND-license: weak copyleft most restrictive'
        if has_apache: return 'apache',         'AND-license: Apache most restrictive'
    else:
        if has_perm:   return 'permissive',    'OR-license: permissive option available'
        if has_apache: return 'apache',         'OR-license: Apache option available'
        if has_lgpl and has_gpl:
            return 'weak_copyleft', 'OR-license: LGPL preferred over GPL'
        if has_lgpl:   return 'weak_copyleft', 'OR-license: LGPL option'
        if has_weak:   return 'weak_copyleft', 'OR-license: weak copyleft option'
        if has_gpl:    return 'gpl',           'OR-license: only GPL option available'
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Content / Font regex  (CC flavor differentiated)
# ─────────────────────────────────────────────────────────────────────────────
# CC-BY-NC / CC-BY-ND → non_oss (caught by SPDX table first; fallback here)
_CC_RESTRICTIVE_RE = re.compile(
    r'\bCC[-\s]BY[-\s](?:NC|ND)\b|CREATIVE\s+COMMONS.*(?:NON.COMMERCIAL|NO.DERIV)',
    re.IGNORECASE,
)
# CC-BY / CC-BY-SA → content
_CONTENT_RE = re.compile(
    r'\bOFL\b|OPEN\s+FONT\s+LIC|SIL\s+OPEN\s+FONT|SIL\s+OFL'
    r'|FONT\s+LIC|FONT\s+AWESOME'
    r'|CREATIVE\s+COMMONS(?!\s*(ZERO|CC0))'  # CC but not CC0
    r'|\bCC[-\s]BY\b(?![-\s](?:NC|ND))'     # CC-BY but not CC-BY-NC/ND
    r'|LPPL|LATEX\s+PROJECT\s+PUBLIC'
    r'|UBUNTU\s+FONT|BITSTREAM\s+VERA|DEJAVU\s+FONTS'
    r'|OPEN\s+GAME\s+LIC|OGL\s+V[0-9]'
    r'|DOCUMENTATION\s+LIC(?!\s+AGREEMENT)'
    r'|\bGFDL\b|GNU\s+FREE\s+DOCUMENTATION',
    re.IGNORECASE,
)


# ─────────────────────────────────────────────────────────────────────────────
# Proprietary / Non-OSS / Government regexes
# ─────────────────────────────────────────────────────────────────────────────
_NON_OSS_RE = re.compile(
    r'NOT\s+(?:BE\s+)?USED\s+FOR\s+EVIL|GOOD\s+NOT\s+EVIL'
    r'|MUST\s+(?:NOT\s+)?BE\s+USED\s+FOR\s+GOOD'
    r'|SHALL\s+NOT\s+BE\s+USED\s+FOR'
    r'|JSON\s+LICEN|WORDNET\s+LICEN'
    r'|FIELD\s+OF\s+USE\s+RESTRICTION|USE\s+RESTRICTION\s+CLAUSE',
    re.IGNORECASE,
)

_PROP_STRONG_RE = re.compile(
    r'\bEULA\b|END[-\s]USER\s+LICEN|END\s+USER\s+LICENSE\s+AGREEMENT'
    r'|SOFTWARE\s+LICENSE\s+AGREEMENT|LICENSE\s+AGREEMENT\b'
    r'|MASTER\s+(?:LICENSE|SOFTWARE)\s+AGREEMENT'
    r'|SUBSCRIPTION\s+(?:LICENSE|AGREEMENT)'
    r'|CONFIDENTIAL(?!\s+INFORMATION\s+OF\s+THE\s+OPEN)'
    r'|NON[\s\-]DISCLOSURE|NDA\s+(?:LICENSE|AGREEMENT|\b)'
    r'|TRADE\s+SECRET'
    r'|NOT\s+(?:FOR\s+)?REDISTRIB|NO\s+REDISTRIB'
    r'|NOT\s+AUTHORIZED\s+TO\s+REDISTRIB'
    r'|REDISTRIBUTION\s+(?:IS\s+)?(?:NOT\s+PERMITTED|PROHIBITED|RESTRICTED)'
    r'|DO\s+NOT\s+(?:DISTRIBUTE|REDISTRIBUTE|COPY|SHARE)'
    r'|PROHIBIT(?:ED|S)\s+(?:ANY\s+)?(?:REDISTRIB|COPYING|SHARING|USE)'
    r'|ALL\s+RIGHTS\s+RESERVED'
    r'|PROPRIETARY\s+(?:LICENSE|AND\s+CONFIDENTIAL|SOFTWARE)'
    r'|COMMERCIAL\s+LICENSE(?!\s+AGREEMENT\s+FOR\s+OPEN)'
    r'|INTERNAL\s+USE\s+ONLY|FOR\s+INTERNAL\s+USE'
    r'|CUSTOMER\s+(?:USE|LICENSE)|CUSTOMER[-\s]SPECIFIC'
    r'|NOT\s+OPEN\s+SOURCE|CLOSED\s+SOURCE'
    r'|NOT[-_\s]?SHIP(?:PED|PING)?|NON[-_\s]?SHIP(?:PED|PING)?|NO[-_\s]?SHIP'
    r'|NOTSHIP(?:PED|PING)?|LINUX\s+NOTSHIP|LINUX[-_]NOTSHIP'
    r'|NOT[-_\s]DISTRIBUTED|UNRELEASED\s+LICENSE'
    r'|\bSDK\s+LICEN|\bWDK\s+LICEN|\bDDK\s+LICEN'
    r'|SOFTWARE\s+DEVELOPMENT\s+KIT.*LICEN'
    r'|DRIVER\s+KIT\s+LICEN|REDISTRIBUTABLE.*SDK',
    re.IGNORECASE,
)

_PROP_WEAK_RE = re.compile(
    r'\bPROPRIETARY\b|RESTRICTED\s+USE|RESTRICTED\s+LICENSE'
    r'|COMMERCIAL\s+ITEM|COMMERCIAL\s+SOFTWARE\b'
    r'|LICENSED\s+MATERIALS|LICENSED\s+PRODUCT'
    r'|EVALUATION\s+(?:LICENSE|ONLY)'
    r'|TRIAL\s+(?:LICENSE|USE|VERSION)'
    r'|REQUIRE[SD]?\s+(?:A\s+)?LICEN(?:SE|CE)',
    re.IGNORECASE,
)

_GOVT_RE = re.compile(
    r'COMMERCIAL\s+ITEM.*FAR|FAR\s+[0-9]'
    r'|DFAR\s+[0-9]|DEFENSE\s+FEDERAL\s+ACQUIS'
    r'|NASA\s+OPEN\s+SOURCE|NOSA\s+1'
    r'|U\.S\.\s+(?:GOVERNMENT|GOV\'?T)\s+(?:RIGHTS|LICENSE|PURPOSE)'
    r'|GOVERNMENT\s+PURPOSE\s+(?:RIGHTS|LICENSE)'
    r'|DOD\s+(?:LICENSE|RIGHTS)|DEPARTMENT\s+OF\s+DEFENSE',
    re.IGNORECASE,
)

_APACHE_RE = re.compile(
    r'\bAPACHE\b|APACHE[-\s]LICEN|APACHE[-\s]2'
    r'|AOSP|ANDROID\s+OPEN\s+SOURCE',
    re.IGNORECASE,
)

_PERMISSIVE_RE = re.compile(
    r'\bMIT\b|MIT[-\s]LICEN|MIT/EXPAT|EXPAT[-\s]LICEN'
    r'|\bBSD\b|BSD-[0-9]|NEW\s+BSD|SIMPLIFIED\s+BSD|MODIFIED\s+BSD|BSD[-\s]LICEN'
    r'|[0-9]-[Cc]lause\b|[0-9]\s+CLAUSE\b'  # bare 'N-clause' without BSD prefix
    r'|REVISED\s+BSD|BSD\s+[0-9][-\s]CLAUSE'
    r'|BSD\d\b|\bBSD[0-9]\b'          # compressed "BSD2", "BSD3", "BSD4"
    r'|\bISC\b|ISC[-\s]LICEN'
    r'|\bZLIB\b|ZLIB[-\s]LICEN|\bLIBPNG\b|LIBPNG[-\s]LICEN'
    r'|\bOPENSSL\b|OPENSSL[-\s]LICEN|SSLEAY'
    r'|BOOST\s+SOFTWARE|BSL-1\.0|BOOST\s+V?1\.'
    r'|\bX11\b|X11[-\s]LICEN|X\s+CONSORTIUM|XFREE86'
    r'|\bNCSA\b|ILLINOIS.*NCSA|NCSA.*LICEN'
    r'|FREETYPE[-\s]LICEN|\bFTL\b'
    r'|PYTHON\s+SOFTWARE\s+FOUNDATION|PSF[-\s]LICEN|\bPSFv?2\b|\bPSF\b'
    r'|HISTORICAL\s+PERMISSION\s+NOTICE|\bHPND\b'
    r'|DO\s+WHAT\s+THE\s+F|WTFPL'
    r'|PUBLIC\s+DOMAIN\s+OR\s+MIT|MIT\s+OR\s+PUBLIC\s+DOMAIN'
    r'|\bUNLIMITED\s+LICEN'
    r'|ZOPE\s+PUBLIC|ZPL[-\s][0-9]'
    r'|PERL\s+ARTISTIC|ARTISTIC[-\s]1'
    r'|\bPHP\s+LICEN|\bPHP\b'
    r'|RUBY\s+LICEN|\bRUBY\b'
    r'|\bLUA\b.*LICEN|LUA\s+[0-9]'
    r'|BZIP2[-\s]LICEN|\bBZIP2\b'
    r'|MUSL[-\s]LICEN|\bMUSL\b'
    r'|OPEN\s+LDAP\s+LICEN|\bOLDAPL\b'
    r'|\bSMLNJ\b|STANDARD\s+ML\s+OF\s+NJ'
    r'|\bTMATE\b|TCP[-\s]WRAPPERS'
    r'|FSFAP\b|FSF\s+ALL.PERMISSIVE'
    r'|PERMISSIVE\s+LICEN(?!.*OASIS)'
    r'|FREE\s+SOFTWARE\s+LICEN(?!.*GPL|.*GNU)'
    r'|SPENCER.*REGEX|REGULAR\s+EXPRESSION\s+LICEN'
    r'|SGI\s+FREE\s+SOFTWARE|SGI\s+FreeB|SGI\s+GLX'
    r'|INFO.?ZIP\s+LICEN|INFO-ZIP',
    re.IGNORECASE,
)

_PUBLIC_DOMAIN_RE = re.compile(
    r'\bPUBLIC\s+DOMAIN\b(?!\s+or|\s+and)'
    r'|\bCC0\b|\bCC0-1\.0\b|CREATIVE\s+COMMONS\s+ZERO'
    r'|\bCCO\b|\bCCO-1\.0\b|\bCCO\s+1\.0\b'  # "CCO" typo for "CC0" (letter O vs zero)
    r'|\bUNLICENSE\b|THE\s+UNLICENSE'
    r'|NO\s+COPYRIGHT|RELEASED\s+INTO\s+THE\s+PUBLIC',
    re.IGNORECASE,
)


# ─────────────────────────────────────────────────────────────────────────────
# Stage 1 — Heading name classifier
# ─────────────────────────────────────────────────────────────────────────────
def _classify_heading(heading_str: str) -> tuple[str, str]:
    """
    Classify based on the license name string from the heading.
    Returns (category, reason).  All rules are vendor-agnostic.
    """
    s = heading_str

    # L0: Filename guard — must run FIRST before any keyword matching.
    # A string ending with a source/doc file extension is a filename, not a license.
    # "linux-kernel-header-gpl2.h" must not match GPL just because it contains "gpl".
    if re.search(r'\.[ch](?:pp|xx)?$|\.h$|\.doc$|\.txt$|\.md$|\.html?$|\.pdf$',
                 s, re.IGNORECASE):
        return 'unknown', 'Filename reference — not a license name, manual review'

    # L1: Dual/OR resolver — must run before single-license SPDX match
    dual = _dual_license_resolve(s)
    if dual:
        return dual

    # L2: SPDX identifier
    result = _match_spdx(s)
    if result:
        flag, spdx_id = result
        return flag, f'SPDX identifier: {spdx_id}'

    # L3a: LGPL — before bare GPL
    if _has_lgpl(s):
        if _has_gpl(s):
            return 'gpl', 'LGPL+GPL combined — GPL most restrictive'
        return 'weak_copyleft', 'LGPL — weak copyleft'

    # L3b: Remaining copyleft
    if _has_gpl(s):   return 'gpl',           'GPL — strong copyleft'
    if _has_mpl(s):   return 'weak_copyleft', 'MPL — weak copyleft'
    if _has_epl(s):   return 'weak_copyleft', 'EPL — weak copyleft'
    if _has_cddl(s):  return 'weak_copyleft', 'CDDL — weak copyleft'
    if _has_eupl(s):  return 'weak_copyleft', 'EUPL — weak copyleft'
    if _has_osl(s):   return 'weak_copyleft', 'OSL — weak copyleft'
    if _has_afl(s):   return 'weak_copyleft', 'AFL — weak copyleft'
    if _has_art(s):   return 'weak_copyleft', 'Artistic/Perl — weak copyleft'

    # L4: CC restrictive before generic CC (NC/ND)
    if _CC_RESTRICTIVE_RE.search(s):
        return 'non_oss', 'CC Non-Commercial/No-Derivatives — field-of-use restriction'

    # L4: Content / Font
    if _CONTENT_RE.search(s):
        return 'content', 'Content/Font license (OFL / CC-BY / font keyword)'

    # L5: Non-OSS
    if _NON_OSS_RE.search(s):
        return 'non_oss', 'Field-of-use restriction clause'

    # L6: Proprietary strong
    if _PROP_STRONG_RE.search(s):
        return 'prop', 'Proprietary — restricted-use / EULA / confidential language'

    # L7: Government
    if _GOVT_RE.search(s):
        return 'prop', 'Government / regulatory license (FAR/DFAR/NASA/DoD)'

    # L8: Apache
    if _APACHE_RE.search(s):
        return 'apache', 'Apache license'

    # L9: Permissive OSS
    if _PERMISSIVE_RE.search(s):
        return 'permissive', 'Permissive OSS license'

    # L10: Public domain
    if _PUBLIC_DOMAIN_RE.search(s):
        return 'public', 'Public domain / CC0 / Unlicense'

    # L11: Proprietary weak
    if _PROP_WEAK_RE.search(s):
        return 'prop', 'Proprietary — restricted-use language'

    return 'unknown', 'No structural pattern matched — manual review required'


# ─────────────────────────────────────────────────────────────────────────────
# Stage 2 — Body-text phrase signature scan
# Called when Stage 1 returns 'unknown' to attempt classification from the
# body pages' actual license text content.
# ─────────────────────────────────────────────────────────────────────────────

# Ordered list of (regex, category, reason, requires_no_oss_phrase)
# The last field means: only fire this rule if no OSS-indicating phrase is present.
_BODY_SIGNATURES: list[tuple[re.Pattern, str, str, bool]] = [
    # Strong copyleft — GPL/LGPL phrases that appear in license body text
    (re.compile(r'GNU GENERAL PUBLIC LICENSE', re.I),
     'gpl', 'Body text: GNU GPL phrase', False),
    # GPL "TERMS AND CONDITIONS FOR COPYING" appears in GPL text before the
    # "GNU GENERAL PUBLIC LICENSE" title line in some extractions
    (re.compile(
        r'TERMS AND CONDITIONS FOR COPYING,\s*DISTRIBUTION AND MODIFICATION'
        r'|TERMS AND CONDITIONS FOR USE,\s*REPRODUCTION,\s*AND DISTRIBUTION', re.I),
     'gpl', 'Body text: GPL/Apache terms-and-conditions header', False),
    (re.compile(r'GNU LESSER GENERAL PUBLIC LICENSE|GNU LIBRARY GENERAL PUBLIC', re.I),
     'weak_copyleft', 'Body text: GNU LGPL phrase', False),
    (re.compile(r'MOZILLA PUBLIC LICENSE|MOZILLA FOUNDATION', re.I),
     'weak_copyleft', 'Body text: MPL phrase', False),
    (re.compile(r'ECLIPSE PUBLIC LICENSE', re.I),
     'weak_copyleft', 'Body text: EPL phrase', False),
    (re.compile(r'COMMON DEVELOPMENT AND DISTRIBUTION', re.I),
     'weak_copyleft', 'Body text: CDDL phrase', False),
    (re.compile(r'APACHE SOFTWARE FOUNDATION|APACHE LICENSE.*VERSION 2'
                r'|LICENSED UNDER THE APACHE LICENSE', re.I),
     'apache', 'Body text: Apache phrase', False),
    # MIT signature — "Permission is hereby granted" (with or without "free of charge")
    # Broadened to catch: "Permission is granted", "Permission to use, copy"
    (re.compile(
        r'PERMISSION IS HEREBY GRANTED'           # classic MIT
        r'|PERMISSION IS GRANTED\b'              # variant: "permission is granted to"
        r'|PERMISSION TO USE,?\s*COPY'           # variant: starts with "permission to use"
        r'|PERMISSION\s+(?:IS\s+)?(?:HEREBY\s+)?GRANTED\s+TO\s+(?:ANY|USE|COPY)', re.I),
     'permissive', 'Body text: MIT/BSD permission grant', False),
    # BSD signature — "Redistribution and use in source and binary forms"
    (re.compile(
        r'REDISTRIBUTION AND USE IN SOURCE AND BINARY FORMS'
        r'|REDISTRIBUTION AND USE,?\s+WITH OR WITHOUT MODIFICATION', re.I),
     'permissive', 'Body text: BSD redistribution clause', False),
    # Zlib / permissive — "as-is" disclaimer with or without quotes/hyphens
    # Covers: "AS IS", "AS-IS", "'as-is'", '"as is"', etc.
    (re.compile(
        r'(?:THIS\s+SOFTWARE\s+IS\s+)?PROVIDED\s+["\']?AS[- ]IS["\']?'
        r'[\s,].*?(?:WITHOUT\s+(?:ANY\s+)?(?:EXPRESS\s+OR\s+IMPLIED\s+)?WARRANTY'
        r'|IN\s+NO\s+EVENT)', re.I | re.DOTALL),
     'permissive', 'Body text: AS-IS disclaimer (zlib/permissive pattern)', False),
    # Public domain — multiple phrasings
    (re.compile(
        r'THIS SOFTWARE IS IN THE PUBLIC DOMAIN'
        r'|PLACED IN THE PUBLIC DOMAIN'
        r'|DEDICATED TO THE PUBLIC DOMAIN'
        r'|RELEASED\s+(?:THIS\s+(?:WORK|CODE|SOFTWARE)\s+)?INTO\s+THE\s+PUBLIC\s+DOMAIN'
        r'|RELEASED\s+TO\s+THE\s+PUBLIC\s+DOMAIN'
        r'|NO COPYRIGHT.*PUBLIC DOMAIN'
        r'|PUBLIC DOMAIN.*NO COPYRIGHT', re.I),
     'public', 'Body text: public domain declaration', False),
    # Creative Commons content
    (re.compile(r'CREATIVE COMMONS ATTRIBUTION(?!\s*(?:NON.COMMERCIAL|NO.DERIV))', re.I),
     'content', 'Body text: CC-BY phrase', False),
    (re.compile(r'CREATIVE COMMONS.*SHARE.ALIKE', re.I),
     'content', 'Body text: CC-BY-SA share-alike', False),
    # Proprietary — only if no OSS phrase was already matched
    (re.compile(r'ALL RIGHTS RESERVED', re.I),
     'prop', 'Body text: all rights reserved', True),
    (re.compile(r'LICENSED,?\s+NOT\s+SOLD', re.I),
     'prop', 'Body text: licensed not sold (proprietary)', True),
    (re.compile(r'YOU MAY NOT\s+(?:COPY|MODIFY|REDISTRIB|SUBLICENS|REVERSE)', re.I),
     'prop', 'Body text: prohibition clause (proprietary)', True),
    (re.compile(r'CONFIDENTIAL\s+(?:AND\s+)?PROPRIETARY', re.I),
     'prop', 'Body text: confidential proprietary', True),
    # Academic-only / commercial-prohibited licenses
    (re.compile(
        r'ACADEMIC\s+(?:USE|PURPOSE|RESEARCH)\s+ONLY'
        r'|FOR\s+(?:NON-COMMERCIAL|ACADEMIC)\s+USE\s+ONLY'
        r'|COMMERCIAL\s+USE\s+(?:IS\s+)?PROHIBITED'
        r'|NOT\s+FOR\s+COMMERCIAL\s+USE', re.I),
     'prop', 'Body text: academic/non-commercial restriction (custom proprietary)', True),
]

# OSS indicator phrases — presence means we suppress weaker proprietary signals
_BODY_OSS_SIGNAL_RE = re.compile(
    r'PERMISSION IS HEREBY GRANTED'
    r'|REDISTRIBUTION AND USE IN SOURCE'
    r'|GNU (?:GENERAL|LESSER) PUBLIC'
    r'|APACHE LICENSE'
    r'|PUBLIC DOMAIN'
    r'|OPEN SOURCE',
    re.IGNORECASE,
)


def _classify_body_text(body_text: str) -> tuple[str, str] | None:
    """
    Stage 2+5: scan body text for license signature phrases, then apply
    Stage 5 structured subtype discrimination when no signature matches.

    Returns (category, reason) or None if body text is too short.

    Stage 2 — signature scan → known license family
    Stage 5 — subtype discrimination → one of:
        unknown_custom    Custom license text (has terms but no known pattern)
        unknown_cr_only   Copyright notice only (no license grant at all)
        unknown_non_sw    Non-software material (documentation, spec)
        unknown_oss_review OSS-adjacent (partial grant language, needs review)
    """
    if not body_text or len(body_text.strip()) < 20:
        return None

    has_oss_signal = bool(_BODY_OSS_SIGNAL_RE.search(body_text))

    # ── Stage 2: signature scan ───────────────────────────────────────────────
    for pattern, cat, reason, requires_no_oss in _BODY_SIGNATURES:
        if requires_no_oss and has_oss_signal:
            continue
        if pattern.search(body_text):
            return cat, reason

    # ── Stage 5: structured subtype discrimination ────────────────────────────
    # Body text exists but no known signature matched.  Rather than a generic
    # "Unknown / CRITICAL", determine the most specific appropriate subtype.
    word_count = len(body_text.split())
    if word_count < 3:
        return None  # Truly empty — only whitespace/punctuation

    # Test for meaningful content signals
    has_copyright   = bool(re.search(r'\bcopyright\b|\(c\)|©', body_text, re.I))
    has_grant       = bool(re.search(
        r'\bpermission\b|\bgranted?\b'
        r'|\bmay\s+(?:use|copy|redistrib)\b'
        r'|\bhereby\b|\blicensed?\s+to\b|\bfree\s+to\b'
        r'|\bpermitted\b', body_text, re.I))
    has_terms       = bool(re.search(
        r'\bterms?\b|\bconditions?\b|\bclause\b|\bobligation\b'
        r'|\brestric\b|\bprohibit\b|\bwarranty\b|\bliability\b'
        r'|\bredistrib\b|\bsublicen', body_text, re.I))
    has_doc_markers = bool(re.search(
        r'\bchapter\b|\bsection\b|\bparagraph\b|\bappendix\b'
        r'|\bfigure\b|\btable\s+of\s+contents\b|\babstract\b'
        r'|\bintroduction\b|\bconclusion\b|\bbibliograph'
        r'|\bheader\s+file\b|\bkernel\s+header\b'          # kernel/C header files
        r'|\bdata\s+structures?\b|\bapi\s+reference\b'      # tech specs
        r'|\bspecification\b|\bspec\s+version\b'            # spec documents
        r'|\bdocumentation\b(?!\s+licen)', body_text, re.I))
    is_short_cr     = (word_count < 40 and has_copyright
                       and not has_grant and not has_terms)

    # Non-software material: document language, no license terms
    if has_doc_markers and not has_terms and not has_grant:
        return ('unknown_non_sw',
                'Non-software material — document/specification, no license terms found')

    # Copyright notice only: has copyright, no grant, no meaningful terms
    if is_short_cr:
        return ('unknown_cr_only',
                'Copyright notice only — no license grant present; '
                'treat as All Rights Reserved')

    # OSS-adjacent: has grant language but no known signature matched
    # (has_grant is the key signal — text offers some right to use)
    if has_grant:
        return ('unknown_oss_review',
                f'OSS-adjacent license — {word_count} words with grant language '
                'but no known signature; manual review required')

    # Custom license: has terms/restrictions but no grant
    if has_terms or (has_copyright and word_count > 40):
        return ('unknown_custom',
                f'Custom license — {word_count} words of license text, '
                'manual review required')

    # Fallback for anything else with enough text
    return ('unknown',
            f'No pattern matched — {word_count} words, manual review required')


# ─────────────────────────────────────────────────────────────────────────────
# Pre-heading fallback classifier
# ─────────────────────────────────────────────────────────────────────────────
def _classify_pre_heading(lines: list[str]) -> tuple[str, str]:
    combined = ' '.join(lines).upper()
    if re.search(r'THIRD PARTY NOTICES REPORT|THIRD.PARTY NOTICE REPORT', combined):
        return 'unknown', 'Pre-heading: report cover page — not a license entry'
    checks = [
        (r'\bOFL\b|OPEN FONT LICEN|SIL OPEN FONT|CREATIVE COMMONS|CC-BY|CC BY\b', 'content', 'Pre-heading: content/font'),
        (r'\bLGPL\b|\bLGPL[-V/]?[0-9]|GNU LESSER GENERAL PUBLIC|LESSER GPL',      'weak_copyleft', 'Pre-heading: LGPL'),
        (r'\bGPL[-V/]?[0-9]|\bGPL\b|\bAGPL\b|GNU GENERAL PUBLIC LICENSE',         'gpl',  'Pre-heading: GPL'),
        (r'\bMPL\b|\bMPLv?[0-9]|MOZILLA PUBLIC|\bEPL\b|ECLIPSE PUBLIC',            'weak_copyleft', 'Pre-heading: weak copyleft'),
        (r'\bCDDL\b|COMMON DEVELOPMENT AND DISTRIBUTION',                            'weak_copyleft', 'Pre-heading: CDDL'),
        (r'APACHE[-\s]?[12]|APACHE LICENSE|\bAOSP\b',                               'apache',  'Pre-heading: Apache'),
        (r'\bMIT\b|\bBSD\b|\bISC\b|\bZLIB\b|\bOPENSSL\b|BOOST SOFTWARE',          'permissive', 'Pre-heading: permissive'),
        (r'\bCC0\b|\bUNLICENSE\b|PUBLIC DOMAIN',                                   'public', 'Pre-heading: public domain'),
        (r'\bEULA\b|\bCONFIDENTIAL\b|ALL RIGHTS RESERVED|NOT FOR REDISTRIB',       'prop',   'Pre-heading: proprietary'),
    ]
    for pattern, cat, reason in checks:
        if re.search(pattern, combined):
            return cat, reason
    return 'unknown', 'Pre-heading: no keyword matched'


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def _clean(value: str) -> str:
    if not isinstance(value, str):
        return ''
    value = re.sub(r'[\x00-\x08\x0B-\x0C\x0E-\x1F]', '', value)
    return unicodedata.normalize('NFKC', value).strip()


def extract_page_lines(page, max_lines: int = 5) -> list[str]:
    text  = page.extract_text() or ''
    lines = [l.strip() for l in text.split('\n') if l.strip()][:max_lines]
    while len(lines) < max_lines:
        lines.append('')
    return [_clean(l) for l in lines]


def _extract_page_text(page) -> str:
    """Full text of a page, used for body-phrase scanning."""
    return _clean(page.extract_text() or '')


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────
def detect_flag_with_reason(lines: list[str]):
    heading_text = _extract_heading_license(lines)
    if heading_text:
        cat, why = _classify_heading(heading_text)
        flag = _FLAG_NORMALISE.get(cat, cat)
        meta = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
        return flag, f'Heading: "{heading_text[:60]}" → {why}', meta
    cat, why = _classify_pre_heading(lines)
    flag = _FLAG_NORMALISE.get(cat, cat)
    meta = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
    return flag, why, meta


def detect_flag(lines: list[str]) -> str:
    return detect_flag_with_reason(lines)[0]


def parse_pdf(pdf_bytes: bytes) -> list[dict]:
    """
    Parse a TPN PDF through the four-stage pipeline:
      Stage 1  — heading-name classification (per heading page)
      Stage 2  — body-phrase scan (upgrades 'unknown' headings after block ends)
      Stage 3  — custom-license fallback labelling
      Stage 4  — body-page inheritance
    """
    reader    = pypdf.PdfReader(io.BytesIO(pdf_bytes))
    full_text = '\n'.join((page.extract_text() or '') for page in reader.pages)

    if _is_summary_format(full_text):
        return _parse_summary_pdf(full_text, pdf_bytes)

    rows: list[dict] = []
    mode              = PageMode.PRE_HEADING
    last_cat          = None
    last_reason       = ''
    last_h_page       = None
    # For Stage 2: accumulate body text while last_cat == 'unknown'
    pending_unknown   = False   # True when current block's Stage-1 = unknown
    pending_body_text = ''      # accumulated body text for Stage 2
    pending_row_idxs  = []      # indices into rows[] that belong to this block

    def _flush_unknown_block():
        """
        Apply Stage 2 / Stage 3 to a finished 'unknown' block.
        Updates rows in-place for all pages in the block.
        """
        nonlocal pending_body_text, pending_row_idxs, pending_unknown
        nonlocal last_cat, last_reason
        if not pending_unknown or not pending_row_idxs:
            pending_unknown   = False
            pending_body_text = ''
            pending_row_idxs  = []
            return

        stage2 = _classify_body_text(pending_body_text)
        if stage2:
            new_flag, new_reason = stage2
            new_flag   = _FLAG_NORMALISE.get(new_flag, new_flag)
            new_meta   = CATEGORY_META.get(new_flag, CATEGORY_META['unknown'])
            # Update heading row
            h_idx = pending_row_idxs[0]
            old_h_reason = rows[h_idx]['reason']
            rows[h_idx]['flag']       = new_flag
            rows[h_idx]['risk']       = new_meta['risk']
            rows[h_idx]['risk_level'] = new_meta['risk_level']
            rows[h_idx]['label']      = new_meta['label']
            rows[h_idx]['reason']     = f'{old_h_reason} → Stage-2: {new_reason}'
            # Update all body rows that inherited from this heading
            for idx in pending_row_idxs[1:]:
                old_r = rows[idx]['reason']
                rows[idx]['flag']       = new_flag
                rows[idx]['risk']       = new_meta['risk']
                rows[idx]['risk_level'] = new_meta['risk_level']
                rows[idx]['label']      = new_meta['label']
                rows[idx]['reason']     = re.sub(
                    r'^(Inherited(?:\s+\(noise/attribution\))?\s+from\s+p\.\d+:)',
                    r'\1',
                    old_r,
                ) + f' → Stage-2: {new_reason}'
            # Update sticky context for any further body pages
            last_cat    = new_flag
            last_reason = rows[h_idx]['reason']

        pending_unknown   = False
        pending_body_text = ''
        pending_row_idxs  = []

    for page_num, page in enumerate(reader.pages, start=1):
        lines    = extract_page_lines(page, max_lines=5)
        l1, l2, l3 = lines[0], lines[1], lines[2]

        if _is_heading_page(lines):
            # Flush any pending unknown block before starting new heading
            _flush_unknown_block()

            mode         = PageMode.HEADING
            heading_text = _extract_heading_license(lines)
            cat, why     = _classify_heading(heading_text)
            flag         = _FLAG_NORMALISE.get(cat, cat)
            meta         = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
            reason       = f'Heading: "{heading_text[:60]}" → {why}'

            if not _is_degenerate_heading(heading_text):
                last_cat, last_reason, last_h_page = flag, reason, page_num

            is_heading, is_noise = True, False

            # Start body-phrase accumulation if Stage 1 returned any unknown variant
            _UNKNOWN_FLAGS = {'unknown', 'unknown_custom', 'unknown_cr_only',
                              'unknown_non_sw', 'unknown_oss_review'}
            if flag in _UNKNOWN_FLAGS and not _is_degenerate_heading(heading_text):
                pending_unknown   = True
                pending_body_text = ''
                pending_row_idxs  = []

        elif mode == PageMode.PRE_HEADING:
            cat, why   = _classify_pre_heading(lines)
            flag       = _FLAG_NORMALISE.get(cat, cat)
            meta       = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
            reason     = why
            is_heading, is_noise = False, False

        else:
            # Body page — inherit classification
            mode     = PageMode.BODY
            flag     = last_cat
            meta     = CATEGORY_META.get(flag, CATEGORY_META['unknown'])
            is_noise = _is_noise_page(lines)
            reason   = (
                f'Inherited (noise/attribution) from p.{last_h_page}: {last_reason}'
                if is_noise else
                f'Inherited from p.{last_h_page}: {last_reason}'
            )
            is_heading = False

            # Accumulate body text for Stage 2
            if pending_unknown:
                page_text = _extract_page_text(page)
                pending_body_text += '\n' + page_text

        row_idx = len(rows)
        rows.append({
            'page': page_num, 'l1': l1, 'l2': l2, 'l3': l3,
            'flag': flag, 'reason': reason,
            'risk': meta['risk'], 'risk_level': meta['risk_level'],
            'label': meta['label'],
            'is_heading_page': is_heading, 'is_noise': is_noise,
            'page_mode': mode.name,
        })

        # Track pending block row indices for Stage 2 back-patching
        if pending_unknown:
            pending_row_idxs.append(row_idx)

    # Flush any pending unknown block at end of PDF
    _flush_unknown_block()

    return rows


def compute_stats(rows: list[dict]) -> dict:
    entry_rows = [
        r for r in rows
        if r.get('is_heading_page')
        or (not r.get('reason', '').startswith('Inherited')
            and not r.get('reason', '').startswith('Pre-heading: report'))
    ]
    counts = {k: 0 for k in CATEGORY_META}
    for r in entry_rows:
        counts[r['flag']] = counts.get(r['flag'], 0) + 1

    # All unknown subtypes count toward the 'unknown' dashboard bucket
    _unknown_total = (counts['unknown'] + counts.get('unknown_custom', 0)
                      + counts.get('unknown_cr_only', 0)
                      + counts.get('unknown_non_sw', 0)
                      + counts.get('unknown_oss_review', 0))

    flagged = (counts['gpl'] + counts['weak_copyleft'] + counts['prop']
               + counts['non_oss'] + _unknown_total)
    return {
        'total':       len(entry_rows),
        'total_pages': len(rows),
        'flagged':     flagged,
        'parsed_ok':   True,
        # Aggregate unknown for dashboard ring display
        'unknown':     _unknown_total,
        'by_mode': {
            'heading':     sum(1 for r in rows if r.get('page_mode') == 'HEADING'),
            'body':        sum(1 for r in rows if r.get('page_mode') == 'BODY'),
            'pre_heading': sum(1 for r in rows if r.get('page_mode') == 'PRE_HEADING'),
            'noise':       sum(1 for r in rows if r.get('is_noise')),
        },
        **{k: v for k, v in counts.items() if k != 'unknown'},
    }
