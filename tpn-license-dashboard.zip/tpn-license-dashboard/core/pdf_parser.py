"""
core/pdf_parser.py  v8.0.0
──────────────────────────
Explicit 3-mode state machine for hierarchical TPN parsing.

DOCUMENT STRUCTURE
==================
A Third-Party Notices PDF is strictly hierarchical:

    [COVER]   Page 1:   "Third Party Notices Report / Project: OpenBMC"
    [HEADING] Page 2:   "Audit - Copyright Acme Corp - Apache 2.0"   ← new block
    [BODY]    Page 3:   "2. Grant of Copyright License. Subject to..."
    [BODY]    Page 4:   "sole responsibility, not on behalf of..."
    [HEADING] Page 5:   "Audit - Copyright OtherLib - GNU GPL v2"     ← new block
    [BODY]    Page 6:   "work, and a 'work based on the Program'..."
    ...

Key observations from data analysis of the OpenBMC TPN report:
  • 100% of heading pages match ^Audit\\s*[-–—]  (132/132)
  • 0 non-Audit headings exist in this format
  • SPDX URLs appear in l2 of many heading pages (not l1)
  • Body pages contain: license text, contributor lists, sub-component listings
  • The longest block: heading p.520 (LGPL) → 187 body pages (p521–p707)

VERSION HISTORY
===============
v6.2.0  Added "strong fulltext override" on body pages — BUG: boilerplate clause
        matches ("as-is", "redistribution permitted") inside GPL/LGPL bodies
        triggered spurious reclassification to 'permissive'.

v7.0.0  Fixed the override bug with _body_page_should_override() guard:
        boilerplate reason strings are disqualified; only risk-escalating
        named-license keyword matches could override.

v8.0.0  Full 3-mode state machine.  Changes from v7:
        1. PageMode enum makes states explicit and auditable.
        2. BODY pages NEVER trigger reclassification — fulltext not called.
           Rationale: every body page is a continuation of the heading.
           There is no legitimate case where license body text changes the
           license type mid-block. The v7 boilerplate guard was correct in
           spirit but still called fulltext unnecessarily.
        3. PRE_HEADING mode for pages before the first heading (cover page,
           report metadata). These receive fulltext classification or 'unknown'.
        4. NOISE detection within BODY blocks: pages matching the attribution
           sub-listing pattern ("packagename version (SPDX-ID)") are tagged
           as noise in the reason string for reporting, but still inherit the
           heading's category (they belong to the heading's component).
        5. Heading detection is purely structural (AUDIT_RE match),
           never keyword-based. A page is a heading if and only if l1
           starts with "Audit -". No license keyword is required.
        6. The heading classifier (_classify_heading) is unchanged: it runs
           only on heading pages, where SPDX-style classification IS correct
           because the heading string is self-describing.

CLASSIFIER APPROPRIATENESS
===========================
SPDX keyword classification is appropriate for HEADING lines because:
  - Heading lines are self-describing: "Apache 2.0", "GNU GPL v2", "MIT License"
  - They are short, structured, and contain the license name explicitly
  - Each heading is an independent license declaration

SPDX keyword classification is NOT appropriate for BODY pages because:
  - Body pages are license text fragments (clauses, preambles, disclaimers)
  - They are NOT self-describing; they only make sense relative to their heading
  - "Permission is hereby granted" appears in MIT AND inside GPL preambles
  - "Redistribution permitted provided..." appears in BSD AND Apache body text
  - "As-is without warranty" appears in nearly every open-source license

3-MODE STATE MACHINE
====================

    ┌──────────────────────────────────────────────────────────┐
    │  Input: PDF page lines (l1, l2, l3, l4, l5)             │
    └──────────────────────────────────────────────────────────┘
                │
                ▼
    ┌──────────────────────┐
    │  AUDIT_RE.match(l1)? │
    └──────────────────────┘
          │YES                    │NO
          ▼                       ▼
    ┌──────────────┐    ┌──────────────────────────┐
    │ MODE: HEADING│    │ last_heading_set?         │
    │              │    └──────────────────────────┘
    │ _classify_   │         │YES          │NO
    │  heading()   │         ▼             ▼
    │              │  ┌──────────┐  ┌──────────────┐
    │ → set        │  │MODE: BODY│  │ MODE: PRE    │
    │   last_cat   │  │          │  │              │
    └──────────────┘  │ inherit  │  │ fulltext()   │
                      │ last_cat │  │ or unknown   │
                      │          │  └──────────────┘
                      │ (detect  │
                      │  noise)  │
                      └──────────┘

NOISE DETECTION (within BODY mode)
===================================
Some body pages are attribution sub-listings rather than license text:
  "bitbake (MIT)"
  "gtest 1.11.0 (BSD-3-Clause)"
  "jQuery 2.0.3 (MIT)"

These match the pattern: name [version] (SPDX-or-keyword)
They still INHERIT the heading's category (they are listed within that
component's section), but are tagged as NOISE in the reason string so
that reporting tools can distinguish them from primary license text.
"""

PARSER_VERSION = "8.0.0"

import re
import io
import unicodedata
from enum import Enum, auto

import pypdf


# ─────────────────────────────────────────────────────────────────────────────
# Page mode enum
# ─────────────────────────────────────────────────────────────────────────────
class PageMode(Enum):
    PRE_HEADING = auto()   # before first heading; no inherited context
    HEADING     = auto()   # page starts a new license block (AUDIT_RE match)
    BODY        = auto()   # continuation of the most recent heading block


# ─────────────────────────────────────────────────────────────────────────────
# Structural heading detector  (100% precision & recall on this TPN format)
# ─────────────────────────────────────────────────────────────────────────────
AUDIT_RE = re.compile(
    r'^Audit\s*[-\u2013\u2014]\s*(?:Copyright\s+)?(.+?)\s*[-\u2013\u2014]\s*(.+)$',
    re.IGNORECASE,
)


def _is_heading_page(lines: list[str]) -> bool:
    """
    A page is a heading if and only if its first non-empty line matches AUDIT_RE.
    This is a purely structural test — no license keyword required.

    In the OpenBMC TPN format (and generally in Blackduck/Scancode TPN outputs),
    every component block starts with a standardised "Audit - Copyright X - License"
    line.  This is the reliable signal; keyword presence is irrelevant here.
    """
    l1 = next((l for l in lines if l.strip()), '')
    return bool(AUDIT_RE.match(l1.strip()))


def _extract_heading_license(lines: list[str]) -> str | None:
    """
    Extract the license name string from a heading page for classification.
    Returns None if this is not a heading page.
    """
    l1 = lines[0].strip() if lines else ''

    # Handle continuation-line headings (heading text wraps to line 2)
    if l1 and l1[-1] in '-\u2013\u2014' and len(lines) > 1 and lines[1].strip():
        l1 = l1.rstrip(' -\u2013\u2014') + ' - ' + lines[1].strip()

    m = AUDIT_RE.match(l1)
    if not m:
        return None

    owner = m.group(1).strip()
    lic   = m.group(2).strip()

    # "Not shipped" variants → preserve for context
    if re.match(r'^not[- ]?ship|^non[- ]?ship|^no[- ]?ship', lic, re.I):
        return (owner + ' - ' + lic).strip()

    # If the license token has no recognisable license term, try appending line 2
    if len(lines) > 1 and not re.search(
        r'(licen|licence|GPL|LGPL|MPL|EPL|CDDL|MIT|BSD|Apache|Public.Domain|'
        r'Proprietary|zlib|ISC|Boost|OpenSSL|libpng|CC0|Unlicense|EULA|FTL|'
        r'Copyleft|Confidential|Unknown|Custom|Artistic|Perl|OFL|Font|CC-BY|'
        r'Curl|JsonCpp|Spencer|XFree|LPPL|SIL|Twemoji)',
        lic, re.IGNORECASE,
    ):
        lic = lic + ' ' + lines[1].strip()

    return lic.strip()


# ─────────────────────────────────────────────────────────────────────────────
# Noise detector — attribution sub-listing within a body block
# ─────────────────────────────────────────────────────────────────────────────
# Matches lines like:
#   "bitbake (MIT)"
#   "gtest 1.11.0 (BSD-3-Clause)"
#   "jquery.cookie 1.4.0 (MIT)"
#   "Files under Apache License 2.0 (Apache-2.0)"
_NOISE_PKG_RE = re.compile(
    r'^[\w][\w\-\.\s]{0,60}\s+\([\w\.\-]+\)\s*$',
    re.IGNORECASE,
)
# Also: lines that are clearly report metadata / separators
_NOISE_META_RE = re.compile(
    r'^-{4,}$'                     # separator lines "--------"
    r'|^={4,}$'                    # "========"
    r'|^Attribution Statements$'   # metadata label
    r'|^License Text$'             # metadata label
    r'|^\(None\)$'                 # placeholder
    r'|^General$',                 # section header
    re.IGNORECASE,
)


def _is_noise_page(lines: list[str]) -> bool:
    """
    Detect attribution sub-listing or metadata pages within a body block.
    These inherit the heading category but are tagged for reporting.
    """
    l1 = lines[0].strip() if lines else ''
    return bool(_NOISE_PKG_RE.match(l1) or _NOISE_META_RE.match(l1))


# ─────────────────────────────────────────────────────────────────────────────
# Category metadata
# ─────────────────────────────────────────────────────────────────────────────
CATEGORY_META = {
    'gpl':           {'label': 'GPL / Strong Copyleft',        'risk': 'HIGH — source disclosure required',           'risk_level': 'high'},
    'weak_copyleft': {'label': 'Weak Copyleft',                'risk': 'MED-HIGH — file/module-level copyleft',       'risk_level': 'med-high'},
    'apache':        {'label': 'Apache',                       'risk': 'MEDIUM — notice + NOTICE file required',      'risk_level': 'medium'},
    'permissive':    {'label': 'Permissive',                   'risk': 'LOW — attribution notice only',               'risk_level': 'low'},
    'public':        {'label': 'Public Domain / CC0',          'risk': 'MINIMAL — no obligations',                    'risk_level': 'minimal'},
    'content':       {'label': 'Content / Font License',       'risk': 'LOW — attribution / embedding rules',         'risk_level': 'low'},
    'prop':          {'label': 'Proprietary',                  'risk': 'HIGH — redistribution restricted',            'risk_level': 'high'},
    'prop_sdk':      {'label': 'Proprietary (SDK/EULA)',       'risk': 'HIGH — SDK redistribution terms apply',       'risk_level': 'high'},
    'non_oss':       {'label': 'Non-OSS / Restrictive',        'risk': 'HIGH — field-of-use restrictions',            'risk_level': 'high'},
    'unknown':       {'label': 'Unknown / Unclassified',       'risk': 'CRITICAL — manual review required',           'risk_level': 'critical'},
}
_FLAG_NORMALISE = {'prop_sdk': 'prop'}


# ─────────────────────────────────────────────────────────────────────────────
# Heading classifier — runs ONLY on heading pages (self-describing input)
# ─────────────────────────────────────────────────────────────────────────────
def _dual_license_resolve(heading_str: str):
    if not re.search(r'\bor\b|\band\b|[/|]', heading_str, re.IGNORECASE):
        return None
    has_perm   = bool(re.search(r'\bMIT\b|\bBSD\b|\bISC\b|\bZLIB\b|\bBoost\b|BSL-1\.0|\bCurl\b|XFree86|\bPSF\b|\bLua\b|JsonCpp|Spencer', heading_str, re.I))
    has_apache = bool(re.search(r'\bApache\b', heading_str, re.I))
    has_weak   = bool(re.search(r'\bLGPL\b|\bMPL\b|\bEPL\b|\bCDDL\b|\bArtistic\b|\bPerl\b', heading_str, re.I))
    has_gpl    = bool(re.search(r'(?<![A-Za-z])GPL(?![A-Za-z])|\bAGPL\b|GNU General Public|Affero', heading_str, re.I))
    if sum([has_perm, has_apache, has_weak, has_gpl]) < 2:
        return None
    if has_perm:   return 'permissive',    'Dual-license: permissive option available'
    if has_apache: return 'apache',         'Dual-license: Apache option available'
    if has_weak and has_gpl: return 'weak_copyleft', 'Dual-license: weak copyleft preferred over GPL'
    return None


def _classify_heading(heading_str: str) -> tuple[str, str]:
    """
    Classify a heading string extracted from an 'Audit - Copyright X - LicName' line.
    Returns (category, reason).

    This function is ONLY called on heading pages where the input is self-describing.
    SPDX-style keyword classification is appropriate here.
    """
    # 0. Library GPL / Not-shipped
    if re.search(r'Library\s+GPL|\bLGPL\b|Library\s+General\s+Public', heading_str, re.I) or \
       re.search(r'not[- ]?ship|non[- ]?ship', heading_str, re.I):
        if re.search(r'(?<![A-Za-z])GPL(?![A-Za-z])|GPL[v\-]?[0-9]', heading_str, re.I):
            return 'weak_copyleft', 'Library GPL / not-shipped — treated as weak copyleft'

    # 1. Dual-license resolver
    result = _dual_license_resolve(heading_str)
    if result:
        return result

    # 2. Content/Font (before GPL, so OFL/Twemoji are caught early)
    if re.search(r'Creative.Commons.Attribution|CC-BY|CC\s+BY\b|\bOFL\b|SIL.Open.Font|'
                 r'Open.Font.Licen|SIL.OFL|Font.Awesome|Google.Fonts|Twemoji|Twitter.Emoji|'
                 r'LPPL|LaTeX.Project.Public', heading_str, re.I):
        return 'content', 'Content/Font license (OFL/CC-BY/Twemoji/LPPL)'

    # 3. GPL / LGPL
    has_lgpl = bool(re.search(r'LGPL|LESSER GPL|GNU LESSER|LIBRARY GENERAL PUBLIC', heading_str, re.I))
    has_mpl  = bool(re.search(r'\bMPL\b|\bMPLv?[0-9]|Mozilla Public', heading_str, re.I))
    has_epl  = bool(re.search(r'\bEPL\b|\bEPLv?[0-9]|Eclipse Public', heading_str, re.I))
    has_weak = has_lgpl or has_mpl or has_epl
    stripped = re.sub(r'L?LGPL\S*', '', heading_str.upper())
    has_gpl  = bool(re.search(
        r'\bGPL[-v/]?[0-9]|\bGPL\b|GNU GENERAL PUBLIC|AFFERO|\bAGPL\b|COPYLEFT|'
        r'GPL\s+LICEN|BISON.EXCEPTION|GCC.RUNTIME|AUTOCONF.*EXCEPTION|'
        r'LIBTOOL.*EXCEPTION|CLASSPATH.EXCEPTION', stripped, re.I))
    if has_gpl and has_weak: return 'gpl',           'GPL overrides weak copyleft in combined heading'
    if has_gpl:              return 'gpl',           'GPL / strong copyleft'
    if has_lgpl:             return 'weak_copyleft', 'LGPL — weak copyleft'
    if has_mpl:              return 'weak_copyleft', 'MPL — weak copyleft'
    if has_epl:              return 'weak_copyleft', 'EPL — weak copyleft'

    # 4. Rule table
    for rx, cat, label in HEADING_RULES:
        m = rx.search(heading_str)
        if m:
            return cat, f'{label} (matched: "{m.group(0)[:40].strip()}")'

    return 'unknown', 'No rule matched — manual review required'


HEADING_RULES = [
    (re.compile(r'(?<![A-Z])GPL(?![A-Z])|GNU GENERAL PUBLIC|AFFERO|COPYLEFT|'
                r'BISON[.\s]EXCEPTION|GCC[.\s]RUNTIME|AUTOCONF.*EXCEPTION|'
                r'LIBTOOL.*EXCEPTION|CLASSPATH[.\s]EXCEPTION', re.I),
     'gpl', 'GPL / strong copyleft'),
    (re.compile(r'\bLGPL\b|\bLGPLv?[0-9]|LGPL-[0-9]|LESSER.GPL|GNU.LESSER|LIBRARY.GENERAL.PUBLIC|'
                r'\bMPL\b|\bMPLv?[0-9]|MOZILLA.PUBLIC|\bEPL\b|\bEPLv?[0-9]|ECLIPSE.PUBLIC|'
                r'\bCDDL\b|COMMON.DEVELOPMENT.AND.DISTRIBUTION|ARTISTIC.LICEN|ARTISTIC-[0-9]|'
                r'\bARTISTIC\b|PERL.LICEN|\bPERL\b', re.I),
     'weak_copyleft', 'Weak copyleft (LGPL/MPL/EPL/CDDL/Artistic/Perl)'),
    (re.compile(r'\bAPACHE\b|AOSP|ANDROID.OPEN.SOURCE|GLSLANG|SHADERC|LUNARG|'
                r'spdx\.org/licenses/Apache', re.I),
     'apache', 'Apache license'),
    (re.compile(r'\bMIT\b|MIT.Licen|Old.MIT|MIT/Expat|Expat.Licen|'
                r'\bBSD\b|BSD-[0-9]|New.BSD|Simplified.BSD|Modified.BSD|BSD.Licen|'
                r'\bISC\b|ISC.Licen|\bZLIB\b|Zlib.Licen|\bLIBPNG\b|libpng.Licen|'
                r'\bOPENSSL\b|OpenSSL.Licen|SSLeay|LibreSSL|'
                r'Boost.v?1\.0|BSL-1\.0|Boost.Software|Info.?ZIP|Unlimited.Licen|'
                r'\bX11\b|X11.Licen|X.Consortium|XFree86|'
                r'\bNCSA\b|Illinois.*NCSA|NCSA.*Licen|\bIJG\b|Independent.JPEG|libjpeg|'
                r'\bCEPHES\b|Public.Domain.or.MIT|MIT.or.Public.Domain|'
                r'\bFTL\b|FreeType.Licen|\bAFL\b|AFL-[0-9]|\bWTFPL\b|DO.WHAT.THE.F|'
                r'\bLua\b.*Licen|Lua.[0-9].Licen|'
                r'Python.Software.Foundation|PSF.Licen|\bPSF\b|PSF-[0-9]|'
                r'zlib/libpng|libpng/zlib|Curl.Licen|\bCurl\b|curl/libcurl|'
                r'JsonCpp.Licen|\bJsonCpp\b|jsoncpp|Henry.Spencer|Spencer.*[Rr]egex|'
                r'libcurl|pycurl|\bpugixml\b|\bcolorama\b|'
                r'sqlite3?\b|SQLite.Licen|\blibevent\b|\bjsmn\b|\bcJSON\b|Jansson', re.I),
     'permissive', 'Permissive (MIT/BSD/ISC/Zlib/OpenSSL/X11/Curl/JsonCpp/Spencer/…)'),
    (re.compile(r'Public\s+Domain(?!\s+or)(?!\s+and)|\bCC0-1\.0\b|\bCC0\b|\bCCO[-\s]?1\.0\b|'
                r'creativecommons\.org/publicdomain|spdx\.org/licenses/CC0|\bUnlicense\b', re.I),
     'public', 'Public Domain / CC0 / Unlicense'),
    (re.compile(r'Creative.Commons.Attribution|CC-BY|CC\s+BY\b|\bOFL\b|SIL.Open.Font|'
                r'Open.Font.Licen|SIL.OFL|SIL\s+Open\s+Font|Font.Awesome|Google.Fonts|'
                r'Twemoji|Twitter.Emoji|LPPL|LaTeX.Project.Public|Ubuntu.Font', re.I),
     'content', 'Content/Font license (CC-BY / OFL / SIL / Twemoji / LPPL)'),
    (re.compile(r'Windows\s+(?:SDK|DDK|WDK|Driver.Kit)|Microsoft\s+(?:SDK|Software.License)|'
                r'Microsoft\s+(?:Developer|Development)\s+(?:License|Tools)|'
                r'SDK\s+Licen|WDK\s+Licen|Redistributable.*SDK|Microsoft.*Redistributable|'
                r'Microsoft.*License.Terms', re.I),
     'prop_sdk', 'Proprietary SDK / EULA'),
    (re.compile(r'Proprietary|CONFIDENTIAL|End.User.Licen|\bEULA\b|'
                r'NO.REDISTRIBUTION|NOT.FOR.DISTRIBUTION|COMMERCIAL.LICEN|INTERNAL.USE.ONLY', re.I),
     'prop', 'Proprietary / restricted'),
    (re.compile(r'JSON.Licen|Good.*Not.*Evil|Not.*Used.*Evil|SHALL.*NOT.*BE.*USED.*FOR|'
                r'MUST.*BE.*USED.*FOR.GOOD|WordNet|VeriSign.*Licen', re.I),
     'non_oss', 'Non-OSS / field-of-use restriction'),
    (re.compile(r'SGI.Free.Software|SGI.GLX|SunPro|SunSoft|Sun.Microsystems.*Licen|'
                r'MPEG.LA|MPEG.*Simulation|Linux.Kernel.Header|OpenRTOS|SafeRTOS|'
                r'Custom.Licen|Unknown.Licen|See.Licen|PlantUML|Makeself|'
                r'MurmurHash|SpookyHash|Mesa\b|WebM|pciutils|Wine\b|PuTTY|'
                r'Dinkumware|P\.J\.\s+Plauger|Mini.XML', re.I),
     'unknown', 'Named library / custom — manual review required'),
]


# ─────────────────────────────────────────────────────────────────────────────
# PRE-HEADING fallback classifier
# Used ONLY when no heading has been seen yet (cover page, report metadata).
# ─────────────────────────────────────────────────────────────────────────────
def _classify_pre_heading(lines: list[str]) -> tuple[str, str]:
    """
    Classify a page that appears before the first heading.
    These are typically the report cover page and are usually unknown.
    We still try fulltext as a best-effort, but these pages are expected
    to be report metadata, not license entries.
    """
    combined = ' '.join(lines).upper()

    if re.search(r'THIRD PARTY NOTICES REPORT|THIRD.PARTY NOTICE REPORT', combined):
        return 'unknown', 'Pre-heading: report cover page — not a license entry'

    # Try lightweight keyword detection (not boilerplate patterns)
    checks = [
        (r'SIL OPEN FONT|OPEN FONT LICEN|\bOFL\b|CREATIVE COMMONS|CC-BY|CC BY\b', 'content', 'Pre-heading: content/font keyword'),
        (r'\bLGPL\b|\bLGPL[-V/]?[0-9]|GNU LESSER GENERAL PUBLIC|LESSER GPL',      'weak_copyleft', 'Pre-heading: LGPL keyword'),
        (r'\bGPL[-V/]?[0-9]|\bGPL\b|\bAGPL\b|GNU GENERAL PUBLIC LICENSE',         'gpl',  'Pre-heading: GPL keyword'),
        (r'\bMPL\b|\bMPLv?[0-9]|MOZILLA PUBLIC|\bEPL\b|ECLIPSE PUBLIC',            'weak_copyleft', 'Pre-heading: weak copyleft keyword'),
        (r'APACHE[-\s]?[12]|APACHE LICENSE|\bAOSP\b',                               'apache',  'Pre-heading: Apache keyword'),
        (r'\bMIT\b|\bBSD\b|\bISC\b|\bZLIB\b|\bOPENSSL\b|BOOST SOFTWARE',          'permissive', 'Pre-heading: permissive keyword'),
        (r'\bCC0\b|\bUNLICENSE\b|PUBLIC DOMAIN',                                   'public', 'Pre-heading: public domain keyword'),
        (r'\bPROPRIETARY\b|\bCONFIDENTIAL\b|\bEULA\b',                             'prop',   'Pre-heading: proprietary keyword'),
    ]
    for pattern, cat, reason in checks:
        if re.search(pattern, combined):
            return cat, reason

    return 'unknown', 'Pre-heading: no keyword matched'


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def _clean(value: str) -> str:
    if not isinstance(value, str):
        return ''
    value = re.sub(r'[\x00-\x08\x0B-\x0C\x0E-\x1F]', '', value)
    return unicodedata.normalize('NFKC', value).strip()


def extract_page_lines(page, max_lines: int = 5) -> list[str]:
    text  = page.extract_text() or ''
    lines = [l.strip() for l in text.split('\n') if l.strip()][:max_lines]
    while len(lines) < max_lines:
        lines.append('')
    return [_clean(l) for l in lines]


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────
def detect_flag_with_reason(lines: list[str]):
    """
    Classify a single page's lines.
    Used by the web UI live-parser which calls this per page.
    Returns (flag, reason, meta).
    """
    heading_text = _extract_heading_license(lines)
    if heading_text:
        cat, why = _classify_heading(heading_text)
        flag = _FLAG_NORMALISE.get(cat, cat)
        meta = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
        return flag, f'Heading: "{heading_text[:60]}" → {why}', meta

    # No heading context available in stateless mode → pre-heading classifier
    cat, why = _classify_pre_heading(lines)
    flag = _FLAG_NORMALISE.get(cat, cat)
    meta = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
    return flag, why, meta


def detect_flag(lines: list[str]) -> str:
    return detect_flag_with_reason(lines)[0]


def parse_pdf(pdf_bytes: bytes) -> list[dict]:
    """
    Parse a TPN PDF and return one row dict per page.

    State machine
    ─────────────
    mode = PRE_HEADING    (no heading seen yet)

    for each page:
        if AUDIT_RE matches l1:
            mode = HEADING
            classify via _classify_heading(heading_text)
            update last_* state
        elif mode == PRE_HEADING:
            classify via _classify_pre_heading(lines)   ← best-effort, no context
        else:  # mode == BODY
            inherit last_cat from heading
            detect noise (attribution sub-listings, separators)
    """
    reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
    rows: list[dict] = []

    # State
    mode         = PageMode.PRE_HEADING
    last_cat     = None
    last_reason  = ''
    last_h_page  = None

    for page_num, page in enumerate(reader.pages, start=1):
        lines = extract_page_lines(page, max_lines=5)
        l1, l2, l3 = lines[0], lines[1], lines[2]

        if _is_heading_page(lines):
            # ── MODE: HEADING ─────────────────────────────────────────────────
            mode = PageMode.HEADING
            heading_text = _extract_heading_license(lines)
            cat, why     = _classify_heading(heading_text)
            flag         = _FLAG_NORMALISE.get(cat, cat)
            meta         = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
            reason       = f'Heading: "{heading_text[:60]}" → {why}'

            last_cat    = flag
            last_reason = reason
            last_h_page = page_num
            is_heading  = True
            is_noise    = False

        elif mode == PageMode.PRE_HEADING:
            # ── MODE: PRE-HEADING (no context yet) ───────────────────────────
            cat, why = _classify_pre_heading(lines)
            flag     = _FLAG_NORMALISE.get(cat, cat)
            meta     = CATEGORY_META.get(cat, CATEGORY_META['unknown'])
            reason   = why
            is_heading = False
            is_noise   = False

        else:
            # ── MODE: BODY (inherit — NO reclassification) ───────────────────
            #
            # Body pages are continuations of the heading block.
            # They contain license text (clauses, preambles, warranty disclaimers),
            # contributor lists, and attribution sub-listings.
            #
            # We do NOT run the classifier on body pages because:
            #   1. License text fragments are not self-describing inputs for SPDX
            #   2. Boilerplate clauses ("as-is", "redistribution permitted") appear
            #      across many license types and cannot be reliably attributed
            #   3. The heading is the authoritative source for the license type
            #
            mode     = PageMode.BODY
            flag     = last_cat
            meta     = CATEGORY_META.get(flag, CATEGORY_META['unknown'])
            is_noise = _is_noise_page(lines)

            if is_noise:
                reason = f'Inherited (noise/attribution) from p.{last_h_page}: {last_reason}'
            else:
                reason = f'Inherited from p.{last_h_page}: {last_reason}'
            is_heading = False

        rows.append({
            'page':            page_num,
            'l1':              l1,
            'l2':              l2,
            'l3':              l3,
            'flag':            flag,
            'reason':          reason,
            'risk':            meta['risk'],
            'risk_level':      meta['risk_level'],
            'label':           meta['label'],
            'is_heading_page': is_heading,
            'is_noise':        is_noise,
            'page_mode':       mode.name,
        })

    return rows


def compute_stats(rows: list[dict]) -> dict:
    """
    Count unique components.

    A row counts as a unique component entry if:
    - it is a heading page (is_heading_page=True), OR
    - it is a pre-heading page that received a non-inherited classification

    Body pages (inherited or noise) are not counted as separate components.
    """
    entry_rows = [
        r for r in rows
        if r.get('is_heading_page')
        or (not r.get('reason', '').startswith('Inherited')
            and not r.get('reason', '').startswith('Pre-heading: report'))
    ]
    counts = {k: 0 for k in CATEGORY_META}
    for r in entry_rows:
        counts[r['flag']] = counts.get(r['flag'], 0) + 1

    flagged = (counts['gpl'] + counts['weak_copyleft'] + counts['prop'] +
               counts['non_oss'] + counts['unknown'])

    return {
        'total':       len(entry_rows),
        'total_pages': len(rows),
        'flagged':     flagged,
        'by_mode': {
            'heading':     sum(1 for r in rows if r.get('page_mode') == 'HEADING'),
            'body':        sum(1 for r in rows if r.get('page_mode') == 'BODY'),
            'pre_heading': sum(1 for r in rows if r.get('page_mode') == 'PRE_HEADING'),
            'noise':       sum(1 for r in rows if r.get('is_noise')),
        },
        **counts,
    }
