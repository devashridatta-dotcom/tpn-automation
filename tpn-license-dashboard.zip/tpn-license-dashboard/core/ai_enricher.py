"""
core/ai_enricher.py  v1.0.0
────────────────────────────
Claude-powered enrichment for rows the keyword parser could not classify.

After the main PDF parse, any heading page with flag='unknown' is sent to
Claude Sonnet for contextual license classification.  The AI understands:
  • Ambiguous headings ("Permissive License", "Custom License")
  • Non-SPDX license names ("SGI Free Software License B", "GetoptLong")
  • Library-specific wording ("SunPro", "CRC-32 Attribution Statements")
  • "Not Shipped" / "Attribution Statements" / non-license headings

The enricher batches up to 30 unknown headings per API call to minimise
latency and cost, then propagates the AI classification to all body pages
that inherited from that heading.

API
───
enrich_unknown_rows(rows)  → returns mutated rows list (in-place update)
                             + stats dict with enrichment counts
"""

import json
import re
import urllib.request
import urllib.error

# ── Category mapping ──────────────────────────────────────────────────────────
# Must align with CATEGORY_META keys in pdf_parser.py
_VALID_FLAGS = {
    'gpl', 'weak_copyleft', 'apache', 'permissive',
    'public', 'content', 'prop', 'non_oss', 'unknown',
}

_SYSTEM_PROMPT = """You are a software license classification expert for a Third-Party Notices (TPN) compliance tool.

You will receive a JSON array of license heading strings extracted from a TPN PDF report.
Each heading is the license name portion of a line like:
  "Audit - Copyright <owner> - <LICENSE_STRING>"

Your job: classify each heading into exactly ONE of these categories:
  • gpl           — GPL, AGPL, strong copyleft; source disclosure required
  • weak_copyleft — LGPL, MPL, EPL, CDDL, Artistic, Perl; file/module-level copyleft
  • apache        — Apache 2.0, AOSP, Android Open Source
  • permissive    — MIT, BSD, ISC, Zlib, OpenSSL, Boost, X11, NCSA, FTL, PSF, Curl, Lua, zlib
  • public        — Public Domain, CC0, Unlicense
  • content       — Creative Commons (non-CC0), OFL/SIL fonts, Twemoji, LPPL
  • prop          — Proprietary, CONFIDENTIAL, EULA, commercial-only
  • non_oss       — Has field-of-use restrictions ("must not be used for evil", JSON license)
  • unknown       — Genuinely ambiguous; cannot determine without reading full license text

Special cases:
  • "Not Shipped", "Not Shipping", "Non-shipping", "No-op" → prop (proprietary / not distributed)
  • "Attribution Statements", "License Text", "No License" → unknown (metadata label, not a license)
  • Dual licenses like "MIT and GPL" → use the MORE RESTRICTIVE: gpl
  • "LGPL or BSD" → weak_copyleft (most restrictive side)
  • Custom / unnamed licenses → unknown unless context strongly suggests a category
  • "Permissive License" with no other context → permissive
  • "BSD-Style License" → permissive
  • "Free Software" without GPL/LGPL qualification → permissive
  • SGI Free Software License B → permissive (it is a BSD-style license)
  • SunPro, SunSoft licenses → permissive (BSD-like academic licenses)
  • GetoptLong → permissive (Ruby/MIT style)
  • CRC-32 (Snippets / Algorithms) → permissive (typically public domain or permissive)
  • Unicode-DFS → permissive (Unicode Data Files license is permissive)
  • NTP License → permissive (MIT-like)
  • W3C License → permissive
  • WTFPL → permissive
  • Beerware → permissive
  • Vim license → permissive (charityware / permissive)
  • PostgreSQL License → permissive (MIT-like)
  • Historical Permission Notice (HPN) → permissive

Respond with ONLY a JSON array in this exact format (no markdown, no explanation):
[
  {"id": 0, "flag": "permissive", "reason": "BSD-style academic license"},
  {"id": 1, "flag": "gpl", "reason": "GPL v2.0 strong copyleft"},
  ...
]

The "reason" must be a concise string (max 80 chars) explaining the classification.
"""

_BATCH_SIZE = 30   # headings per API call


def _call_claude(headings: list[str]) -> list[dict]:
    """
    Call Claude Sonnet to classify a batch of license headings.
    Returns list of {id, flag, reason} dicts.
    """
    payload = json.dumps({
        "model": "claude-sonnet-4-20250514",
        "max_tokens": 1500,
        "system": _SYSTEM_PROMPT,
        "messages": [
            {
                "role": "user",
                "content": (
                    "Classify these license headings:\n"
                    + json.dumps(
                        [{"id": i, "heading": h} for i, h in enumerate(headings)],
                        indent=2
                    )
                )
            }
        ]
    }).encode()

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read())

    # Extract text from response
    text = ""
    for block in data.get("content", []):
        if block.get("type") == "text":
            text += block["text"]

    # Strip markdown fences if present
    text = re.sub(r"```(?:json)?", "", text).strip()

    results = json.loads(text)

    # Validate
    validated = []
    for item in results:
        flag = item.get("flag", "unknown")
        if flag not in _VALID_FLAGS:
            flag = "unknown"
        validated.append({
            "id":     int(item.get("id", 0)),
            "flag":   flag,
            "reason": str(item.get("reason", "AI classified"))[:120],
        })
    return validated


def enrich_unknown_rows(rows: list[dict]) -> dict:
    """
    Find all heading rows with flag='unknown', send them to Claude in batches,
    and update the rows in-place with the AI classification.

    Also propagates the new flag to all BODY rows that inherited from an
    enriched heading.

    Returns a stats dict:
      {
        "total_unknown":    int,   # unknown heading rows before enrichment
        "enriched":         int,   # successfully reclassified by AI
        "still_unknown":    int,   # remained unknown after AI pass
        "api_calls":        int,   # number of Claude API calls made
        "errors":           list,  # any errors encountered
      }
    """
    # ── 1. Collect unknown heading rows ───────────────────────────────────────
    unknown_headings: list[tuple[int, int, str]] = []  # (row_idx, page_num, heading)
    for idx, row in enumerate(rows):
        if row.get("flag") == "unknown" and row.get("is_heading_page"):
            # Extract the heading string from reason or l1
            heading = _extract_heading_from_row(row)
            unknown_headings.append((idx, row["page"], heading))

    stats = {
        "total_unknown": len(unknown_headings),
        "enriched":      0,
        "still_unknown": 0,
        "api_calls":     0,
        "errors":        [],
    }

    if not unknown_headings:
        return stats

    # ── 2. Process in batches ─────────────────────────────────────────────────
    # Build a map: page_num → (row_idx, new_flag, new_reason)
    page_updates: dict[int, tuple[str, str]] = {}

    for batch_start in range(0, len(unknown_headings), _BATCH_SIZE):
        batch = unknown_headings[batch_start: batch_start + _BATCH_SIZE]
        headings_only = [h for _, _, h in batch]

        try:
            results = _call_claude(headings_only)
            stats["api_calls"] += 1

            for item in results:
                local_id = item["id"]
                if local_id >= len(batch):
                    continue
                row_idx, page_num, _ = batch[local_id]
                new_flag   = item["flag"]
                new_reason = f'AI: {item["reason"]}'
                page_updates[page_num] = (new_flag, new_reason)

                if new_flag != "unknown":
                    stats["enriched"] += 1
                else:
                    stats["still_unknown"] += 1

        except Exception as exc:
            stats["errors"].append(str(exc))
            stats["still_unknown"] += len(batch)
            continue

    # ── 3. Apply updates to heading rows ─────────────────────────────────────
    for idx, row in enumerate(rows):
        if row.get("is_heading_page") and row.get("flag") == "unknown":
            page_num = row["page"]
            if page_num in page_updates:
                new_flag, new_reason = page_updates[page_num]
                rows[idx]["flag"]   = new_flag
                rows[idx]["reason"] = new_reason
                rows[idx]["ai_classified"] = True

    # ── 4. Propagate to BODY rows that inherited from enriched headings ───────
    #   Body row reasons look like: "Inherited from p.N: ..."
    #   Re-scan in order, tracking last heading state
    last_heading_page   = None
    last_heading_flag   = None
    last_heading_reason = None

    for idx, row in enumerate(rows):
        if row.get("is_heading_page"):
            last_heading_page   = row["page"]
            last_heading_flag   = row["flag"]
            last_heading_reason = row["reason"]
        elif row.get("page_mode") in ("BODY",) and last_heading_page is not None:
            # Only update if the heading was AI-enriched
            if last_heading_page in page_updates:
                noise_prefix = "Inherited (noise/attribution)" if row.get("is_noise") else "Inherited"
                rows[idx]["flag"]   = last_heading_flag
                rows[idx]["reason"] = (
                    f'{noise_prefix} from p.{last_heading_page}: {last_heading_reason}'
                )

    return stats


def _extract_heading_from_row(row: dict) -> str:
    """
    Extract the best human-readable heading string from a parsed row.
    The reason field contains: 'Heading: "LicenseName" → No rule matched'
    Prefer that over l1 which may be the raw 'Audit - Copyright X - Y' line.
    """
    reason = row.get("reason", "")
    m = re.search(r'Heading:\s*"([^"]{1,120})"', reason)
    if m:
        return m.group(1).strip()
    # Fall back to l1 minus the Audit prefix
    l1 = row.get("l1", "")
    audit_m = re.match(
        r'^Audit\s*[-–—]\s*(?:Copyright\s+)?(.+?)\s*[-–—]\s*(.+)$',
        l1, re.IGNORECASE
    )
    if audit_m:
        return audit_m.group(2).strip()
    return l1[:100]
