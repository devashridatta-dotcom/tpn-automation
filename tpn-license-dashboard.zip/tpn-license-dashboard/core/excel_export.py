"""
core/excel_export.py  v2.0.0
─────────────────────────────
XLSX export for TPN License Intelligence Dashboard.

Produces a workbook with sheets:
  1. All Components      — all 707 pages, colour-coded by risk category
  2. Needs Attention     — GPL, Weak Copyleft, Proprietary, Non-OSS, Unknown only
  3. GPL Strong Copyleft — GPL pages only
  4. Weak Copyleft       — LGPL / MPL / EPL / CDDL pages
  5. Apache              — Apache licensed pages
  6. Permissive          — MIT / BSD / ISC / Zlib / etc.
  7. Public Domain CC0   — Public Domain / CC0 / Unlicense
  8. Content Font License— CC-BY / OFL / SIL / Twemoji
  9. Proprietary         — Proprietary / SDK/EULA pages
  10.NonOSS Restrictive  — JSON License / field-of-use restrictions
  11.Unknown Unclassified— unclassified / manual review required
  12.Summary             — category counts and percentages

Config
──────
To change column widths       → edit COLUMN_WIDTHS
To change row colours         → edit CAT_FILL
To change which sheets appear → edit build_xlsx() sheet list
To add a new sheet            → copy the _write_sheet() call pattern
"""

import io
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ─────────────────────────────────────────────────────────────────────────────
# Style config — edit here to change the look
# ─────────────────────────────────────────────────────────────────────────────

FONT_NAME = 'Arial'
FONT_SIZE = 10

HEADER_FONT_COLOR = 'FFFFFF'
HEADER_FILL_COLOR = '1C2230'    # dark navy

# Per-category fill and font colours (hex, no #)
CAT_FILL = {
    'gpl':           {'fill': 'FEE2DF', 'font': 'C0392B'},   # red tint
    'weak_copyleft': {'fill': 'FEF0E7', 'font': 'C2500A'},   # orange tint
    'apache':        {'fill': 'FFFDE7', 'font': '976900'},   # amber tint
    'permissive':    {'fill': 'E8F5E9', 'font': '2E7D32'},   # green tint
    'public':        {'fill': 'E0F7FA', 'font': '006064'},   # cyan tint
    'content':       {'fill': 'E3F2FD', 'font': '1565C0'},   # blue tint
    'prop':          {'fill': 'F3E5F5', 'font': '6A1B9A'},   # purple tint
    'non_oss':       {'fill': 'FCE4EC', 'font': 'B71C1C'},   # crimson tint
    'unknown':       {'fill': 'F1F3F7', 'font': '4A5568'},   # grey tint
}

PAGE_TEXT_COLOR = '8899AA'      # muted grey for page number column

COLUMN_WIDTHS = {
    'A': 7,    # Page
    'B': 62,   # Component / Title
    'C': 50,   # Line 2
    'D': 50,   # Line 3
    'E': 26,   # Category
    'F': 36,   # Risk Level
    'G': 70,   # Classification Reason
}

ROW_HEIGHT    = 28
HEADER_HEIGHT = 22

# Human-readable labels for each flag
CAT_LABEL = {
    'gpl':           'GPL / Strong Copyleft',
    'weak_copyleft': 'Weak Copyleft',
    'apache':        'Apache',
    'permissive':    'Permissive',
    'public':        'Public Domain / CC0',
    'content':       'Content / Font License',
    'prop':          'Proprietary',
    'non_oss':       'Non-OSS / Restrictive',
    'unknown':       'Unknown / Unclassified',
}

CAT_RISK = {
    'gpl':           'HIGH — source disclosure required',
    'weak_copyleft': 'MED-HIGH — file/module-level copyleft',
    'apache':        'MEDIUM — notice + NOTICE file required',
    'permissive':    'LOW — attribution notice only',
    'public':        'MINIMAL — no obligations',
    'content':       'LOW — attribution / embedding rules',
    'prop':          'HIGH — redistribution restricted',
    'non_oss':       'HIGH — field-of-use restrictions',
    'unknown':       'CRITICAL — manual review required',
}

# Category order for sheets and summary
CATS_ORDER = [
    'gpl', 'weak_copyleft', 'apache', 'permissive',
    'public', 'content', 'prop', 'non_oss', 'unknown',
]

FLAGGED_CATS = {'gpl', 'weak_copyleft', 'prop', 'non_oss', 'unknown'}

# Sheet names per category (max 31 chars)
CAT_SHEET_NAME = {
    'gpl':           'GPL Strong Copyleft',
    'weak_copyleft': 'Weak Copyleft',
    'apache':        'Apache',
    'permissive':    'Permissive',
    'public':        'Public Domain CC0',
    'content':       'Content Font License',
    'prop':          'Proprietary',
    'non_oss':       'NonOSS Restrictive',
    'unknown':       'Unknown Unclassified',
}


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_styles() -> dict:
    """Build reusable openpyxl style objects."""
    def _font(color: str = '000000', bold: bool = False) -> Font:
        return Font(name=FONT_NAME, size=FONT_SIZE, bold=bold, color=color)

    def _fill(hex_color: str) -> PatternFill:
        return PatternFill('solid', fgColor=hex_color)

    thin = Border(bottom=Side(style='thin', color='D0DAF0'))

    styles: dict = {
        'hdr_font':  Font(name=FONT_NAME, size=FONT_SIZE, bold=True, color=HEADER_FONT_COLOR),
        'hdr_fill':  _fill(HEADER_FILL_COLOR),
        'hdr_align': Alignment(horizontal='center', vertical='center'),
        'page_font': _font(PAGE_TEXT_COLOR),
        'base_font': _font(),
        'base_bold': _font(bold=True),
        'border':    thin,
    }

    # Per-category fill + font styles
    for cat, colors in CAT_FILL.items():
        styles[f'{cat}_fill'] = _fill(colors['fill'])
        styles[f'{cat}_font'] = _font(colors['font'])
        styles[f'{cat}_bold'] = _font(colors['font'], bold=True)

    return styles


def _write_header(ws, s: dict) -> None:
    """Write and style the header row."""
    headers = [
        'Page', 'Component / Title', 'Line 2', 'Line 3',
        'Category', 'Risk Level', 'Classification Reason',
    ]
    ws.append(headers)
    for cell in ws[1]:
        cell.font      = s['hdr_font']
        cell.fill      = s['hdr_fill']
        cell.alignment = s['hdr_align']
    ws.row_dimensions[1].height = HEADER_HEIGHT
    ws.freeze_panes = 'A2'

    for col_letter, width in COLUMN_WIDTHS.items():
        ws.column_dimensions[col_letter].width = width


def _style_data_row(ws, row_idx: int, flag: str, s: dict) -> None:
    """Apply colour and alignment to a data row."""
    fill_key = f'{flag}_fill'
    font_key = f'{flag}_font'
    bold_key = f'{flag}_bold'

    has_style = fill_key in s

    for col_idx, cell in enumerate(ws[row_idx], start=1):
        if has_style:
            cell.fill = s[fill_key]
            if col_idx == 1:
                cell.font = s['page_font']
            elif col_idx == 2:
                cell.font = s[bold_key]
            else:
                cell.font = s[font_key]
        else:
            cell.font = s['page_font'] if col_idx == 1 else (
                s['base_bold'] if col_idx == 2 else s['base_font'])

        cell.border = s['border']
        cell.alignment = Alignment(
            vertical='center',
            wrap_text=(col_idx in (2, 3, 4, 7)),
        )

    ws.row_dimensions[row_idx].height = ROW_HEIGHT


def _write_sheet(ws, rows: list[dict], s: dict) -> None:
    """Write header + data rows to a worksheet."""
    _write_header(ws, s)
    for r in rows:
        flag = r.get('flag', 'unknown')
        ws.append([
            r.get('page', ''),
            r.get('l1', ''),
            r.get('l2', ''),
            r.get('l3', ''),
            CAT_LABEL.get(flag, flag.upper()),
            r.get('risk', CAT_RISK.get(flag, '')),
            r.get('reason', ''),
        ])
        _style_data_row(ws, ws.max_row, flag, s)


def _write_summary(ws, rows: list[dict], s: dict) -> None:
    """Write the Summary sheet with category counts and percentages."""
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 26
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 12
    ws.column_dimensions['E'].width = 42

    # Header
    ws.append(['Category Key', 'Label', 'Count', '% of Total', 'Risk Level'])
    for cell in ws[1]:
        cell.font      = s['hdr_font']
        cell.fill      = s['hdr_fill']
        cell.alignment = s['hdr_align']
    ws.row_dimensions[1].height = HEADER_HEIGHT
    ws.freeze_panes = 'A2'

    total = len(rows)
    flagged_total = sum(1 for r in rows if r.get('flag') in FLAGGED_CATS)

    for cat in CATS_ORDER:
        count = sum(1 for r in rows if r.get('flag') == cat)
        pct   = f'{count / total * 100:.1f}%' if total else '0.0%'
        ws.append([
            cat.upper(),
            CAT_LABEL.get(cat, cat),
            count,
            pct,
            CAT_RISK.get(cat, ''),
        ])
        row_idx = ws.max_row
        fill_key = f'{cat}_fill'
        for col_idx, cell in enumerate(ws[row_idx], start=1):
            if fill_key in s:
                cell.fill = s[fill_key]
            cell.font      = Font(name=FONT_NAME, size=FONT_SIZE)
            cell.border    = s['border']
            cell.alignment = Alignment(
                horizontal='left' if col_idx in (1, 2, 5) else 'center',
                vertical='center',
            )
        ws.row_dimensions[row_idx].height = ROW_HEIGHT

    # Blank separator
    ws.append(['', '', '', '', ''])

    # Totals
    for label, count, note in [
        ('TOTAL',           total,          '100%'),
        ('NEEDS ATTENTION', flagged_total,  f'{flagged_total / total * 100:.1f}%' if total else '0%'),
    ]:
        ws.append([label, '', count, note, 'Manual review or legal sign-off required' if label == 'NEEDS ATTENTION' else ''])
        row_idx = ws.max_row
        for cell in ws[row_idx]:
            cell.font   = Font(name=FONT_NAME, size=FONT_SIZE, bold=True)
            cell.border = s['border']
            cell.alignment = Alignment(horizontal='center', vertical='center')
        ws.row_dimensions[row_idx].height = ROW_HEIGHT


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def build_xlsx(rows: list[dict]) -> bytes:
    """
    Build a formatted XLSX workbook from parsed TPN rows.

    Parameters
    ----------
    rows : list[dict]
        Each dict must contain at minimum:
          page, l1, l2, l3, flag, risk, reason

    Returns
    -------
    bytes
        Raw .xlsx bytes ready to stream as a file download.
    """
    wb = openpyxl.Workbook()
    s  = _make_styles()

    # Sheet 1 — All Components
    ws_all        = wb.active
    ws_all.title  = 'All Components'
    _write_sheet(ws_all, rows, s)

    # Sheet 2 — Needs Attention
    ws_flag       = wb.create_sheet('Needs Attention')
    flagged_rows  = [r for r in rows if r.get('flag') in FLAGGED_CATS]
    _write_sheet(ws_flag, flagged_rows, s)

    # Sheets 3–11 — one per category (only created if rows exist)
    for cat in CATS_ORDER:
        cat_rows = [r for r in rows if r.get('flag') == cat]
        if not cat_rows:
            continue
        ws_cat = wb.create_sheet(CAT_SHEET_NAME[cat])
        _write_sheet(ws_cat, cat_rows, s)

    # Sheet 12 — Summary
    ws_sum = wb.create_sheet('Summary')
    _write_summary(ws_sum, rows, s)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()
