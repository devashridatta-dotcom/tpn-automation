# TPN License Intelligence Dashboard

**Version:** 8.0.0  
**Parser:** v8.0.0 — Explicit 3-mode hierarchical state machine  
**Stack:** Python 3.11+ · Flask · pypdf · openpyxl

A self-hosted web application that parses Third-Party Notices PDF reports and produces a searchable, filterable license intelligence dashboard with Excel export.

---

## Quick Start

```bash
# 1. Unzip
unzip tpn-license-dashboard.zip
cd tpn-license-dashboard

# 2. Create virtual environment
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run
python app.py

# 5. Open browser
open http://localhost:5000
```

---

## Full Installation Guide

### Prerequisites

| Requirement | Version | Check |
|---|---|---|
| Python | 3.11 or higher | `python3 --version` |
| pip | Latest | `pip --version` |

If Python is not installed:
- **macOS:** `brew install python3` or download from [python.org](https://python.org)
- **Windows:** Download from [python.org](https://python.org) — check "Add to PATH"
- **Linux:** `sudo apt install python3 python3-pip python3-venv`

---

### Step-by-step Installation

#### Step 1 — Unzip the package

```bash
unzip tpn-license-dashboard.zip
cd tpn-license-dashboard
```

#### Step 2 — Create a virtual environment

A virtual environment keeps the project's dependencies isolated from your system Python.

```bash
# Create the environment
python3 -m venv .venv

# Activate it
source .venv/bin/activate          # macOS / Linux
.venv\Scripts\activate             # Windows CMD
.venv\Scripts\Activate.ps1        # Windows PowerShell
```

You will see `(.venv)` at the start of your terminal prompt when it is active.

#### Step 3 — Install Python dependencies

```bash
pip install -r requirements.txt
```

This installs three packages:

| Package | Purpose |
|---|---|
| `flask` | Web server and API routing |
| `pypdf` | PDF text extraction (page-by-page) |
| `openpyxl` | Excel (.xlsx) workbook generation |

Installation typically takes 30–60 seconds.

#### Step 4 — Run the server

```bash
python app.py
```

You will see:

```
  ┌──────────────────────────────────────────────────────┐
  │  TPN License Intelligence Dashboard  v8.0.0          │
  │                                                      │
  │  Parser:  v8.0.0 (3-mode state machine)              │
  │  Open:    http://localhost:5000                      │
  │  Health:  http://localhost:5000/api/health           │
  └──────────────────────────────────────────────────────┘
```

#### Step 5 — Open the dashboard

Navigate to **http://localhost:5000** in your browser.

To stop the server: press `Ctrl + C` in the terminal.

---

## Using the Dashboard

### Uploading a TPN PDF

1. Click **⬆ Upload Data** in the header
2. Drop a Third-Party Notices PDF or click to browse
3. The parser processes the file page by page (progress bar shown)
4. The dashboard populates automatically

### Dashboard features

| Feature | Description |
|---|---|
| **Ring chart** | 9-segment donut — each segment is a license category, click to filter |
| **KPI cards** | Total components, license types, pages parsed, flagged % |
| **Donut charts** | Obligation level breakdown + classification distribution |
| **Detail report** | Click any ring or "View Detailed Report" |
| **Filter chips** | Filter by license category with count badges |
| **Search** | Full-text search across component names and license text |
| **Export XLSX** | Downloads a 12-sheet Excel workbook |

### Detail report

- Shows all 707 pages with badges, risk levels, and attribution links
- Filter chips show real counts: `Weak CL 312`, `GPL 236`, etc.
- Clicking a ring segment filters the table and scrolls to results
- Active filter banner shows category, count, percentage, and risk level

---

## API Reference

The server exposes a REST API used by the dashboard UI.

### `GET /api/health`

Returns server and parser version.

```json
{
  "status": "ok",
  "parser_version": "8.0.0",
  "app_version": "8.0.0"
}
```

### `POST /api/parse-pdf`

Parses a TPN PDF. Request must be `multipart/form-data` with a `file` field.

```bash
curl -X POST http://localhost:5000/api/parse-pdf \
  -F "file=@Third_party_notices.pdf"
```

Response:

```json
{
  "filename": "Third_party_notices.pdf",
  "rows": [
    {
      "page": 2,
      "l1": "Audit - Copyright Acme - Apache 2.0",
      "l2": "License",
      "l3": "(https://spdx.org/licenses/Apache-2.0.html)",
      "flag": "apache",
      "risk": "MEDIUM — notice + NOTICE file required",
      "risk_level": "medium",
      "label": "Apache",
      "reason": "Heading: \"Apache 2.0\" → Apache license",
      "is_heading_page": true,
      "is_noise": false,
      "page_mode": "HEADING"
    }
  ],
  "stats": {
    "total": 132,
    "total_pages": 707,
    "flagged": 564,
    "by_mode": {
      "heading": 132,
      "body": 574,
      "pre_heading": 1,
      "noise": 23
    },
    "gpl": 236,
    "weak_copyleft": 312,
    "apache": 38,
    "permissive": 87,
    "public": 3,
    "content": 15,
    "prop": 1,
    "non_oss": 1,
    "unknown": 14
  }
}
```

### `POST /api/export-xlsx`

Generates an Excel workbook from parsed rows.

```bash
curl -X POST http://localhost:5000/api/export-xlsx \
  -H "Content-Type: application/json" \
  -d '{"rows": [...]}' \
  --output third-party-notices.xlsx
```

Returns a `.xlsx` file download.

---

## Project Structure

```
tpn-license-dashboard/
│
├── app.py                    ← Flask server (routes + API)
│
├── core/
│   ├── __init__.py
│   ├── pdf_parser.py         ← v8.0.0 hierarchical TPN parser
│   │                           3-mode state machine:
│   │                           PRE_HEADING / HEADING / BODY
│   │                           Noise detection for attribution sub-listings
│   └── excel_export.py       ← v2.0.0 XLSX export
│                               12-sheet workbook with per-category colour coding
│
├── static/
│   ├── dashboard.css         ← UI styles (CSS custom properties)
│   ├── dashboard.js          ← Client-side logic
│   ├── demo.config.js        ← Demo data configuration
│   └── favicon.svg           ← Browser tab icon
│
├── templates/
│   └── dashboard.html        ← Main Jinja2 template
│
├── uploads/                  ← Temporary upload directory (auto-created)
│
├── requirements.txt          ← pip dependencies
└── README.md                 ← This file
```

---

## Parser Architecture (v8.0.0)

The parser uses an explicit 3-mode state machine:

```
Page N:   "Audit - Copyright Acme - Apache 2.0"  →  MODE: HEADING
Page N+1: "2. Grant of Copyright License..."      →  MODE: BODY (inherit apache)
Page N+2: "sole responsibility, not on behalf..." →  MODE: BODY (inherit apache)
Page N+3: "Audit - Copyright OtherLib - GPL v2"  →  MODE: HEADING (new block)
Page N+4: "11. BECAUSE THE PROGRAM IS LICENSED..."→  MODE: BODY (inherit gpl)
```

**Key design decisions:**

1. **Heading = `Audit -` prefix only.** All 132 headings in the OpenBMC TPN report match this pattern. No license keyword is needed to detect a heading — it is a purely structural test.

2. **Body pages are never reclassified.** The SPDX keyword classifier is appropriate for heading lines (self-describing inputs). It is NOT appropriate for body pages — license text fragments contain cross-license boilerplate ("as-is", "redistribution permitted") that cannot be reliably attributed without heading context.

3. **Noise detection.** Attribution sub-listings (`"gtest 1.11.0 (BSD-3-Clause)"`) are tagged as noise in the reason field but still inherit the heading category.

4. **Dual-license resolver.** Headings containing `or`, `and`, `/`, or `|` between license names resolve to the least-restrictive option (permissive > apache > weak_copyleft > gpl).

---

## Configuration

### Change the port

```bash
python app.py --port 8080
```

Or edit `app.py`:

```python
app.run(debug=True, port=8080)
```

### Production deployment

For production use, replace Flask's development server with Gunicorn:

```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Disable debug mode

Edit `app.py`:

```python
app.run(debug=False, port=5000)
```

---

## Troubleshooting

### `ModuleNotFoundError: No module named 'flask'`

The virtual environment is not activated. Run:
```bash
source .venv/bin/activate   # macOS / Linux
.venv\Scripts\activate      # Windows
```

### `Port 5000 is already in use`

Change the port:
```bash
# Edit app.py: app.run(port=5001)
python app.py
```

Or kill the existing process:
```bash
lsof -ti:5000 | xargs kill   # macOS / Linux
```

### `pypdf` extraction returns empty text

Some PDFs use image-based text (scanned). pypdf cannot extract text from images. The parser requires a text-based PDF. If your TPN report is scanned, request a text version from the tool that generated it.

### PDF uploads over 100 MB fail

Edit `app.py`:
```python
app.config['MAX_CONTENT_LENGTH'] = 200 * 1024 * 1024   # 200 MB
```

---

## License

Internal tooling — all rights reserved.
