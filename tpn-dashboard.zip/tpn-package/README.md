# TPN License Intelligence Dashboard

A standalone, single-file web dashboard for Third Party Notices (TPN) license analysis.

## Quick Start (No Installation Required)

Simply open `index.html` in any modern web browser — no server, no dependencies, no internet required (except for PDF upload feature which uses CDN libraries).

```
Double-click index.html → opens in browser
```

---

## Running Locally (Optional — for PDF upload feature)

If you want to upload a new Third Party Notices PDF for live parsing, you can run a simple local server to avoid browser CORS restrictions.

### Option 1: Python (Recommended — pre-installed on Mac/Linux)

```bash
# Navigate to the folder
cd tpn-package

# Python 3
python3 -m http.server 5000

# Then open your browser at:
http://localhost:5000
```

### Option 2: Node.js

```bash
# Install serve globally (one-time)
npm install -g serve

# Navigate to the folder
cd tpn-package

# Run
serve . -p 5000

# Then open your browser at:
http://localhost:5000
```

### Option 3: VS Code Live Server

1. Install the **Live Server** extension in VS Code
2. Right-click `index.html` → **Open with Live Server**

---

## Features

- **TPN Ring Dashboard** — 9-category license breakdown donut ring (clickable segments)
- **Detailed Report** — Full paginated component table with search, filter chips, risk badges
- **Ring Click Filtering** — Click any ring segment to filter the table to that category
- **Export XLSX** — Exports multi-sheet Excel file (All Components, Needs Attention, per-category, Summary)
- **PDF Upload** — Upload a new Third Party Notices PDF to parse and analyse live
- **Pre-loaded Data** — Comes with OpenBMC TPN data (132 components, 707 pages) built in

## License Categories

| Category | Count | Risk |
|---|---|---|
| GPL / Strong Copyleft | 47 | HIGH |
| Weak Copyleft | 19 | MED-HIGH |
| Apache | 14 | MEDIUM |
| Permissive | 38 | LOW |
| Public Domain / CC0 | 3 | MINIMAL |
| Content / Font | 3 | LOW |
| Proprietary | 1 | HIGH |
| Non-OSS | 1 | HIGH |
| Unknown | 7 | CRITICAL |

## Requirements

- Any modern browser (Chrome, Firefox, Edge, Safari)
- No Node.js, Python, or other tools required for basic use
